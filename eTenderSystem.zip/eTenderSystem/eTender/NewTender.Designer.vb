﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewTender
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.grbNoticeDetails = New System.Windows.Forms.GroupBox()
        Me.txtTime = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpClosingDate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTenderNum = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtNoticeInfo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNextTendInfo = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.grbTenderDoc = New System.Windows.Forms.GroupBox()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.grbNoticeDetails.SuspendLayout()
        Me.grbTenderDoc.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblHeader.Font = New System.Drawing.Font("Calibri", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(12, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(316, 38)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "Tender Information"
        Me.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grbNoticeDetails
        '
        Me.grbNoticeDetails.Controls.Add(Me.txtTime)
        Me.grbNoticeDetails.Controls.Add(Me.Label5)
        Me.grbNoticeDetails.Controls.Add(Me.dtpClosingDate)
        Me.grbNoticeDetails.Controls.Add(Me.Label4)
        Me.grbNoticeDetails.Controls.Add(Me.dtpIssueDate)
        Me.grbNoticeDetails.Controls.Add(Me.Label3)
        Me.grbNoticeDetails.Controls.Add(Me.txtTenderNum)
        Me.grbNoticeDetails.Controls.Add(Me.Label2)
        Me.grbNoticeDetails.Controls.Add(Me.txtNoticeInfo)
        Me.grbNoticeDetails.Controls.Add(Me.Label1)
        Me.grbNoticeDetails.Location = New System.Drawing.Point(13, 78)
        Me.grbNoticeDetails.Name = "grbNoticeDetails"
        Me.grbNoticeDetails.Size = New System.Drawing.Size(315, 216)
        Me.grbNoticeDetails.TabIndex = 1
        Me.grbNoticeDetails.TabStop = False
        Me.grbNoticeDetails.Text = "Tender Notice Details"
        '
        'txtTime
        '
        Me.txtTime.Location = New System.Drawing.Point(103, 178)
        Me.txtTime.Name = "txtTime"
        Me.txtTime.Size = New System.Drawing.Size(99, 23)
        Me.txtTime.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(12, 178)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 23)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Time:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpClosingDate
        '
        Me.dtpClosingDate.Location = New System.Drawing.Point(103, 149)
        Me.dtpClosingDate.Name = "dtpClosingDate"
        Me.dtpClosingDate.Size = New System.Drawing.Size(200, 23)
        Me.dtpClosingDate.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(12, 149)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 14)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Closing Date:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtpIssueDate
        '
        Me.dtpIssueDate.Location = New System.Drawing.Point(103, 116)
        Me.dtpIssueDate.Name = "dtpIssueDate"
        Me.dtpIssueDate.Size = New System.Drawing.Size(200, 23)
        Me.dtpIssueDate.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(12, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Date of Issue:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTenderNum
        '
        Me.txtTenderNum.Location = New System.Drawing.Point(103, 79)
        Me.txtTenderNum.Name = "txtTenderNum"
        Me.txtTenderNum.Size = New System.Drawing.Size(200, 23)
        Me.txtTenderNum.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(0, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Tender Number:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtNoticeInfo
        '
        Me.txtNoticeInfo.Location = New System.Drawing.Point(103, 34)
        Me.txtNoticeInfo.Name = "txtNoticeInfo"
        Me.txtNoticeInfo.Size = New System.Drawing.Size(200, 23)
        Me.txtNoticeInfo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(9, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tender Notice:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnNextTendInfo
        '
        Me.btnNextTendInfo.Location = New System.Drawing.Point(116, 428)
        Me.btnNextTendInfo.Name = "btnNextTendInfo"
        Me.btnNextTendInfo.Size = New System.Drawing.Size(99, 23)
        Me.btnNextTendInfo.TabIndex = 2
        Me.btnNextTendInfo.Text = "Next >>"
        Me.btnNextTendInfo.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(221, 428)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(107, 23)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'grbTenderDoc
        '
        Me.grbTenderDoc.Controls.Add(Me.lblMessage)
        Me.grbTenderDoc.Controls.Add(Me.btnUpload)
        Me.grbTenderDoc.Location = New System.Drawing.Point(13, 315)
        Me.grbTenderDoc.Name = "grbTenderDoc"
        Me.grbTenderDoc.Size = New System.Drawing.Size(315, 107)
        Me.grbTenderDoc.TabIndex = 4
        Me.grbTenderDoc.TabStop = False
        Me.grbTenderDoc.Text = "Tender Document"
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(15, 22)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(150, 23)
        Me.btnUpload.TabIndex = 2
        Me.btnUpload.Text = "Upload File to Server"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'lblMessage
        '
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMessage.ForeColor = System.Drawing.Color.Red
        Me.lblMessage.Location = New System.Drawing.Point(15, 58)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(288, 35)
        Me.lblMessage.TabIndex = 3
        '
        'frmNewTender
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 465)
        Me.Controls.Add(Me.grbTenderDoc)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnNextTendInfo)
        Me.Controls.Add(Me.grbNoticeDetails)
        Me.Controls.Add(Me.lblHeader)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmNewTender"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New Tender Information"
        Me.grbNoticeDetails.ResumeLayout(False)
        Me.grbNoticeDetails.PerformLayout()
        Me.grbTenderDoc.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents grbNoticeDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtTime As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents dtpClosingDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtpIssueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTenderNum As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNoticeInfo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnNextTendInfo As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents grbTenderDoc As System.Windows.Forms.GroupBox
    Friend WithEvents btnUpload As System.Windows.Forms.Button
    Friend WithEvents lblMessage As System.Windows.Forms.Label
End Class
