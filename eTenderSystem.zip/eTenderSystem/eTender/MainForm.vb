﻿Public Class frmMainForm
    Friend WithEvents NewSupplier As New frmNewSupplier
    Friend WithEvents NewUser As New frmNewUser
    Friend WithEvents SuppGroup As New frmSupplierGroupDetail
    Friend WithEvents SuppMainCont As New frmSupplierMainContact
    Friend WithEvents SuppDetails As New frmSupplierDetails
    Friend WithEvents TenderDocs As New frmTenderDocument
    Friend WithEvents NewTender As New frmNewTender
    Friend WithEvents BidWinner As New frmBidWinner
    Friend WithEvents ActivateSupp As New frmActivateSupplierAcc
    Friend WithEvents Login As New frmLogin
    Friend WithEvents Invite As New frmInviteSupplier

    Private Sub SupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnsNewSupplier.Click
        NewSupplier = New frmNewSupplier
        NewSupplier.MdiParent = Me
        NewSupplier.Show()
    End Sub

    Private Sub UserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnsNewUser.Click
        NewUser = New frmNewUser
        NewUser.MdiParent = Me
        NewUser.Show()
    End Sub

    Private Sub SupplierDetailsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SupplierDetailsToolStripMenuItem1.Click
        SuppDetails = New frmSupplierDetails
        SuppDetails.MdiParent = Me
        SuppDetails.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub TenderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnsNewTender.Click
        NewTender = New frmNewTender
        NewTender.MdiParent = Me
        NewTender.Show()
    End Sub

    Private Sub TenderToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles mnsManageTender.Click

    End Sub

    Private Sub mnsViewWinner_Click(sender As Object, e As EventArgs) Handles mnsViewWinner.Click
        Dim strTenderNunmber As String

        strTenderNunmber = InputBox("Enter Tender Number:")

        If strTenderNunmber = "" Then
            MessageBox.Show("Please enter Tender Number", "Tender Number")
            strTenderNunmber = InputBox("Enter Tender Number:")
            If strTenderNunmber <> "" Then
                BidWinner = New frmBidWinner
                BidWinner.MdiParent = Me
                BidWinner.Show()
            Else
                MessageBox.Show("Please enter Tender Number", "Tender Number")
            End If
        Else
            BidWinner = New frmBidWinner
            BidWinner.MdiParent = Me
            BidWinner.Show()
        End If
    End Sub

    Private Sub ActivateSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnsActivateSupplier.Click
        ActivateSupp = New frmActivateSupplierAcc
        ActivateSupp.MdiParent = Me
        ActivateSupp.Show()
    End Sub

    Private Sub InviteSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnsInviteSupplier.Click

    End Sub

    Private Sub frmMainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mnsNew.Enabled = False
        mnsOpen.Enabled = False
        mnsManage.Enabled = False
        mnsSupplier.Enabled = False
        mnsTools.Enabled = False

        Login = New frmLogin
        Login.MdiParent = Me
        Login.Show()
        mnsLogout.Text = "&Login"
        lblUserDetails.Visible = False
    End Sub
End Class
