﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSupplierMainContact
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tcMainContact = New System.Windows.Forms.TabControl()
        Me.tpMainContact = New System.Windows.Forms.TabPage()
        Me.txtMainEmail = New System.Windows.Forms.TextBox()
        Me.txtMainFax = New System.Windows.Forms.TextBox()
        Me.txtMainCell = New System.Windows.Forms.TextBox()
        Me.txtMainPosition = New System.Windows.Forms.TextBox()
        Me.txtMainName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tcSalesPerson = New System.Windows.Forms.TabPage()
        Me.txtSalesEmail = New System.Windows.Forms.TextBox()
        Me.txtSalesFax = New System.Windows.Forms.TextBox()
        Me.txtSalesCell = New System.Windows.Forms.TextBox()
        Me.txtSalesPosition = New System.Windows.Forms.TextBox()
        Me.txtSalesName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tpNumEmployees = New System.Windows.Forms.TabPage()
        Me.nudPartTime = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.nudFullTime = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnSaveAll = New System.Windows.Forms.Button()
        Me.tcMainContact.SuspendLayout()
        Me.tpMainContact.SuspendLayout()
        Me.tcSalesPerson.SuspendLayout()
        Me.tpNumEmployees.SuspendLayout()
        CType(Me.nudPartTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudFullTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tcMainContact
        '
        Me.tcMainContact.Controls.Add(Me.tpMainContact)
        Me.tcMainContact.Controls.Add(Me.tcSalesPerson)
        Me.tcMainContact.Controls.Add(Me.tpNumEmployees)
        Me.tcMainContact.Location = New System.Drawing.Point(12, 12)
        Me.tcMainContact.Name = "tcMainContact"
        Me.tcMainContact.SelectedIndex = 0
        Me.tcMainContact.Size = New System.Drawing.Size(436, 197)
        Me.tcMainContact.TabIndex = 0
        '
        'tpMainContact
        '
        Me.tpMainContact.Controls.Add(Me.txtMainEmail)
        Me.tpMainContact.Controls.Add(Me.txtMainFax)
        Me.tpMainContact.Controls.Add(Me.txtMainCell)
        Me.tpMainContact.Controls.Add(Me.txtMainPosition)
        Me.tpMainContact.Controls.Add(Me.txtMainName)
        Me.tpMainContact.Controls.Add(Me.Label5)
        Me.tpMainContact.Controls.Add(Me.Label4)
        Me.tpMainContact.Controls.Add(Me.Label3)
        Me.tpMainContact.Controls.Add(Me.Label2)
        Me.tpMainContact.Controls.Add(Me.Label1)
        Me.tpMainContact.Location = New System.Drawing.Point(4, 24)
        Me.tpMainContact.Name = "tpMainContact"
        Me.tpMainContact.Padding = New System.Windows.Forms.Padding(3)
        Me.tpMainContact.Size = New System.Drawing.Size(428, 169)
        Me.tpMainContact.TabIndex = 0
        Me.tpMainContact.Text = "Main Contact Person"
        Me.tpMainContact.UseVisualStyleBackColor = True
        '
        'txtMainEmail
        '
        Me.txtMainEmail.Location = New System.Drawing.Point(148, 133)
        Me.txtMainEmail.Name = "txtMainEmail"
        Me.txtMainEmail.Size = New System.Drawing.Size(251, 23)
        Me.txtMainEmail.TabIndex = 9
        '
        'txtMainFax
        '
        Me.txtMainFax.Location = New System.Drawing.Point(148, 103)
        Me.txtMainFax.Name = "txtMainFax"
        Me.txtMainFax.Size = New System.Drawing.Size(251, 23)
        Me.txtMainFax.TabIndex = 8
        '
        'txtMainCell
        '
        Me.txtMainCell.Location = New System.Drawing.Point(148, 73)
        Me.txtMainCell.Name = "txtMainCell"
        Me.txtMainCell.Size = New System.Drawing.Size(251, 23)
        Me.txtMainCell.TabIndex = 7
        '
        'txtMainPosition
        '
        Me.txtMainPosition.Location = New System.Drawing.Point(149, 42)
        Me.txtMainPosition.Name = "txtMainPosition"
        Me.txtMainPosition.Size = New System.Drawing.Size(250, 23)
        Me.txtMainPosition.TabIndex = 6
        '
        'txtMainName
        '
        Me.txtMainName.Location = New System.Drawing.Point(149, 9)
        Me.txtMainName.Name = "txtMainName"
        Me.txtMainName.Size = New System.Drawing.Size(250, 23)
        Me.txtMainName.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(6, 130)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(135, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Email Address:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(6, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(135, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Fax:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(6, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(135, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Cellphone Number:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(6, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Company Position:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(7, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tcSalesPerson
        '
        Me.tcSalesPerson.Controls.Add(Me.txtSalesEmail)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesFax)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesCell)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesPosition)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesName)
        Me.tcSalesPerson.Controls.Add(Me.Label6)
        Me.tcSalesPerson.Controls.Add(Me.Label7)
        Me.tcSalesPerson.Controls.Add(Me.Label8)
        Me.tcSalesPerson.Controls.Add(Me.Label9)
        Me.tcSalesPerson.Controls.Add(Me.Label10)
        Me.tcSalesPerson.Location = New System.Drawing.Point(4, 24)
        Me.tcSalesPerson.Name = "tcSalesPerson"
        Me.tcSalesPerson.Padding = New System.Windows.Forms.Padding(3)
        Me.tcSalesPerson.Size = New System.Drawing.Size(428, 169)
        Me.tcSalesPerson.TabIndex = 1
        Me.tcSalesPerson.Text = "Sales Person"
        Me.tcSalesPerson.UseVisualStyleBackColor = True
        '
        'txtSalesEmail
        '
        Me.txtSalesEmail.Location = New System.Drawing.Point(148, 133)
        Me.txtSalesEmail.Name = "txtSalesEmail"
        Me.txtSalesEmail.Size = New System.Drawing.Size(251, 23)
        Me.txtSalesEmail.TabIndex = 19
        '
        'txtSalesFax
        '
        Me.txtSalesFax.Location = New System.Drawing.Point(148, 103)
        Me.txtSalesFax.Name = "txtSalesFax"
        Me.txtSalesFax.Size = New System.Drawing.Size(251, 23)
        Me.txtSalesFax.TabIndex = 18
        '
        'txtSalesCell
        '
        Me.txtSalesCell.Location = New System.Drawing.Point(148, 73)
        Me.txtSalesCell.Name = "txtSalesCell"
        Me.txtSalesCell.Size = New System.Drawing.Size(251, 23)
        Me.txtSalesCell.TabIndex = 17
        '
        'txtSalesPosition
        '
        Me.txtSalesPosition.Location = New System.Drawing.Point(149, 42)
        Me.txtSalesPosition.Name = "txtSalesPosition"
        Me.txtSalesPosition.Size = New System.Drawing.Size(250, 23)
        Me.txtSalesPosition.TabIndex = 16
        '
        'txtSalesName
        '
        Me.txtSalesName.Location = New System.Drawing.Point(149, 9)
        Me.txtSalesName.Name = "txtSalesName"
        Me.txtSalesName.Size = New System.Drawing.Size(250, 23)
        Me.txtSalesName.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(6, 130)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(135, 25)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Email Address:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(6, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(135, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Fax:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(6, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(135, 25)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Cellphone Number:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(6, 42)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(135, 25)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Company Position:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(7, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(135, 25)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Name:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tpNumEmployees
        '
        Me.tpNumEmployees.Controls.Add(Me.nudPartTime)
        Me.tpNumEmployees.Controls.Add(Me.Label12)
        Me.tpNumEmployees.Controls.Add(Me.nudFullTime)
        Me.tpNumEmployees.Controls.Add(Me.Label11)
        Me.tpNumEmployees.Location = New System.Drawing.Point(4, 24)
        Me.tpNumEmployees.Name = "tpNumEmployees"
        Me.tpNumEmployees.Padding = New System.Windows.Forms.Padding(3)
        Me.tpNumEmployees.Size = New System.Drawing.Size(428, 169)
        Me.tpNumEmployees.TabIndex = 2
        Me.tpNumEmployees.Text = "Number of Employees"
        Me.tpNumEmployees.UseVisualStyleBackColor = True
        '
        'nudPartTime
        '
        Me.nudPartTime.Location = New System.Drawing.Point(171, 59)
        Me.nudPartTime.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudPartTime.Name = "nudPartTime"
        Me.nudPartTime.Size = New System.Drawing.Size(62, 23)
        Me.nudPartTime.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(26, 59)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(139, 23)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Part Time Employees:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'nudFullTime
        '
        Me.nudFullTime.Location = New System.Drawing.Point(171, 19)
        Me.nudFullTime.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudFullTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudFullTime.Name = "nudFullTime"
        Me.nudFullTime.Size = New System.Drawing.Size(62, 23)
        Me.nudFullTime.TabIndex = 1
        Me.nudFullTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(26, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(139, 23)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Full Time Employees:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnSaveAll
        '
        Me.btnSaveAll.Location = New System.Drawing.Point(271, 216)
        Me.btnSaveAll.Name = "btnSaveAll"
        Me.btnSaveAll.Size = New System.Drawing.Size(172, 23)
        Me.btnSaveAll.TabIndex = 1
        Me.btnSaveAll.Text = "Save ALL Supplier Details"
        Me.btnSaveAll.UseVisualStyleBackColor = True
        '
        'frmSupplierMainContact
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(457, 244)
        Me.Controls.Add(Me.btnSaveAll)
        Me.Controls.Add(Me.tcMainContact)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmSupplierMainContact"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Supplier Contact Persons"
        Me.tcMainContact.ResumeLayout(False)
        Me.tpMainContact.ResumeLayout(False)
        Me.tpMainContact.PerformLayout()
        Me.tcSalesPerson.ResumeLayout(False)
        Me.tcSalesPerson.PerformLayout()
        Me.tpNumEmployees.ResumeLayout(False)
        CType(Me.nudPartTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudFullTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tcMainContact As System.Windows.Forms.TabControl
    Friend WithEvents tpMainContact As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tcSalesPerson As System.Windows.Forms.TabPage
    Friend WithEvents txtMainEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtMainFax As System.Windows.Forms.TextBox
    Friend WithEvents txtMainCell As System.Windows.Forms.TextBox
    Friend WithEvents txtMainPosition As System.Windows.Forms.TextBox
    Friend WithEvents txtMainName As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesFax As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesCell As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesPosition As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tpNumEmployees As System.Windows.Forms.TabPage
    Friend WithEvents nudPartTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents nudFullTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnSaveAll As System.Windows.Forms.Button
End Class
