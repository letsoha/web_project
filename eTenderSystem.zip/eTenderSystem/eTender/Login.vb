﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Data.OleDb.OleDbConnection
Imports eTender.frmMainForm

Public Class frmLogin
    Dim SystemProcesses As New eTenderClass

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        frmMainForm.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim myConn As String
        Dim dsUsers As New DataSet
        Dim strUsername As String
        Dim strPassword As String
        Dim strAccessType As String
        Dim MainFrm As New frmMainForm

        myConn = SystemProcesses.GetConnection()

        If myConn <> "true" Then
            MsgBox("There was no connection to System Database.", MsgBoxStyle.Information)
        Else
            dsUsers = SystemProcesses.GetUserDetails(txtUsername.Text)
            If dsUsers.Tables("UserDetails").Rows.Count = 0 Then
                MsgBox("Username does not exist.", MsgBoxStyle.Exclamation)
                txtUsername.Clear()
                txtPassword.Clear()
                txtUsername.Focus()
            Else
                strUsername = dsUsers.Tables("UserDetails").Rows(0).Item("Username")
                strPassword = dsUsers.Tables("UserDetails").Rows(0).Item("usrPassword")
                strAccessType = dsUsers.Tables("UserDetails").Rows(0).Item("usrAccessType")
                If txtPassword.Text <> strPassword Then
                    MessageBox.Show("Invalid Password entered.", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    txtPassword.Clear()
                    txtPassword.Focus()
                Else
                    If strAccessType = "Administrator" Then

                        frmMainForm.mnsNew.Enabled = True
                        frmMainForm.mnsOpen.Enabled = True
                        frmMainForm.mnsManage.Enabled = True
                        frmMainForm.mnsSupplier.Enabled = True
                        frmMainForm.mnsTools.Enabled = True
                        Me.Close()
                        frmMainForm.lblUserDetails.Visible = True
                        frmMainForm.lblUserDetails.Text = "Welcome: " & StrConv(strUsername, vbUpperCase)
                        frmMainForm.mnsLogout.Text = "&Logout"
                    Else
                        If strAccessType = "Clerk" Then
                            frmMainForm.mnsNew.Enabled = True
                            frmMainForm.mnsNewTender.Enabled = False
                            frmMainForm.mnsNewUser.Enabled = False
                            frmMainForm.mnsManage.Enabled = True
                            frmMainForm.mnsManageTender.Enabled = False
                            frmMainForm.mnsManageSupplier.Enabled = False
                            frmMainForm.mnsInviteSupplier.Enabled = True
                            frmMainForm.mnsViewWinner.Enabled = False
                            frmMainForm.mnsSupplier.Enabled = True
                            frmMainForm.mnsActivateSupplier.Enabled = False
                            Me.Close()
                            frmMainForm.mnsLogout.Text = "&Logout"
                            frmMainForm.lblUserDetails.Visible = True
                            frmMainForm.lblUserDetails.Text = "Welcome: " & StrConv(strUsername, vbUpperCase)
                        End If
                    End If
                End If
            End If
        End If


    End Sub
End Class