﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSupplierGroupDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grbGroupDetail = New System.Windows.Forms.GroupBox()
        Me.lblSpecify = New System.Windows.Forms.Label()
        Me.txtOther = New System.Windows.Forms.TextBox()
        Me.chkOther = New System.Windows.Forms.CheckBox()
        Me.chkGovPar = New System.Windows.Forms.CheckBox()
        Me.chkSec21Co = New System.Windows.Forms.CheckBox()
        Me.chkTrust = New System.Windows.Forms.CheckBox()
        Me.chkPartnership = New System.Windows.Forms.CheckBox()
        Me.chkForeign = New System.Windows.Forms.CheckBox()
        Me.chkSolePro = New System.Windows.Forms.CheckBox()
        Me.chkConsortium = New System.Windows.Forms.CheckBox()
        Me.chkJointVen = New System.Windows.Forms.CheckBox()
        Me.chkCC = New System.Windows.Forms.CheckBox()
        Me.chkPrivCoLtd = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkPubCoLtd = New System.Windows.Forms.CheckBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.grbGroupDetail.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbGroupDetail
        '
        Me.grbGroupDetail.Controls.Add(Me.lblSpecify)
        Me.grbGroupDetail.Controls.Add(Me.txtOther)
        Me.grbGroupDetail.Controls.Add(Me.chkOther)
        Me.grbGroupDetail.Controls.Add(Me.chkGovPar)
        Me.grbGroupDetail.Controls.Add(Me.chkSec21Co)
        Me.grbGroupDetail.Controls.Add(Me.chkTrust)
        Me.grbGroupDetail.Controls.Add(Me.chkPartnership)
        Me.grbGroupDetail.Controls.Add(Me.chkForeign)
        Me.grbGroupDetail.Controls.Add(Me.chkSolePro)
        Me.grbGroupDetail.Controls.Add(Me.chkConsortium)
        Me.grbGroupDetail.Controls.Add(Me.chkJointVen)
        Me.grbGroupDetail.Controls.Add(Me.chkCC)
        Me.grbGroupDetail.Controls.Add(Me.chkPrivCoLtd)
        Me.grbGroupDetail.Controls.Add(Me.Label1)
        Me.grbGroupDetail.Controls.Add(Me.chkPubCoLtd)
        Me.grbGroupDetail.Location = New System.Drawing.Point(12, 12)
        Me.grbGroupDetail.Name = "grbGroupDetail"
        Me.grbGroupDetail.Size = New System.Drawing.Size(238, 464)
        Me.grbGroupDetail.TabIndex = 0
        Me.grbGroupDetail.TabStop = False
        Me.grbGroupDetail.Text = "Supplier Grouping Detail"
        '
        'lblSpecify
        '
        Me.lblSpecify.Location = New System.Drawing.Point(10, 430)
        Me.lblSpecify.Name = "lblSpecify"
        Me.lblSpecify.Size = New System.Drawing.Size(49, 23)
        Me.lblSpecify.TabIndex = 14
        Me.lblSpecify.Text = "Specify:"
        Me.lblSpecify.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtOther
        '
        Me.txtOther.Location = New System.Drawing.Point(65, 430)
        Me.txtOther.Name = "txtOther"
        Me.txtOther.Size = New System.Drawing.Size(148, 23)
        Me.txtOther.TabIndex = 13
        '
        'chkOther
        '
        Me.chkOther.AutoSize = True
        Me.chkOther.Location = New System.Drawing.Point(10, 399)
        Me.chkOther.Name = "chkOther"
        Me.chkOther.Size = New System.Drawing.Size(57, 19)
        Me.chkOther.TabIndex = 12
        Me.chkOther.Text = "Other"
        Me.chkOther.UseVisualStyleBackColor = True
        '
        'chkGovPar
        '
        Me.chkGovPar.AutoSize = True
        Me.chkGovPar.Location = New System.Drawing.Point(10, 373)
        Me.chkGovPar.Name = "chkGovPar"
        Me.chkGovPar.Size = New System.Drawing.Size(167, 19)
        Me.chkGovPar.TabIndex = 11
        Me.chkGovPar.Text = "Government / Parastatals"
        Me.chkGovPar.UseVisualStyleBackColor = True
        '
        'chkSec21Co
        '
        Me.chkSec21Co.AutoSize = True
        Me.chkSec21Co.Location = New System.Drawing.Point(10, 347)
        Me.chkSec21Co.Name = "chkSec21Co"
        Me.chkSec21Co.Size = New System.Drawing.Size(136, 19)
        Me.chkSec21Co.TabIndex = 10
        Me.chkSec21Co.Text = "Section 21 Company"
        Me.chkSec21Co.UseVisualStyleBackColor = True
        '
        'chkTrust
        '
        Me.chkTrust.AutoSize = True
        Me.chkTrust.Location = New System.Drawing.Point(10, 321)
        Me.chkTrust.Name = "chkTrust"
        Me.chkTrust.Size = New System.Drawing.Size(53, 19)
        Me.chkTrust.TabIndex = 9
        Me.chkTrust.Text = "Trust"
        Me.chkTrust.UseVisualStyleBackColor = True
        '
        'chkPartnership
        '
        Me.chkPartnership.AutoSize = True
        Me.chkPartnership.Location = New System.Drawing.Point(10, 295)
        Me.chkPartnership.Name = "chkPartnership"
        Me.chkPartnership.Size = New System.Drawing.Size(91, 19)
        Me.chkPartnership.TabIndex = 8
        Me.chkPartnership.Text = "Partnership"
        Me.chkPartnership.UseVisualStyleBackColor = True
        '
        'chkForeign
        '
        Me.chkForeign.AutoSize = True
        Me.chkForeign.Location = New System.Drawing.Point(10, 269)
        Me.chkForeign.Name = "chkForeign"
        Me.chkForeign.Size = New System.Drawing.Size(121, 19)
        Me.chkForeign.TabIndex = 7
        Me.chkForeign.Text = "Foreign Company"
        Me.chkForeign.UseVisualStyleBackColor = True
        '
        'chkSolePro
        '
        Me.chkSolePro.AutoSize = True
        Me.chkSolePro.Location = New System.Drawing.Point(10, 243)
        Me.chkSolePro.Name = "chkSolePro"
        Me.chkSolePro.Size = New System.Drawing.Size(109, 19)
        Me.chkSolePro.TabIndex = 6
        Me.chkSolePro.Text = "Sole Proprietor"
        Me.chkSolePro.UseVisualStyleBackColor = True
        '
        'chkConsortium
        '
        Me.chkConsortium.AutoSize = True
        Me.chkConsortium.Location = New System.Drawing.Point(10, 217)
        Me.chkConsortium.Name = "chkConsortium"
        Me.chkConsortium.Size = New System.Drawing.Size(89, 19)
        Me.chkConsortium.TabIndex = 5
        Me.chkConsortium.Text = "Consortium"
        Me.chkConsortium.UseVisualStyleBackColor = True
        '
        'chkJointVen
        '
        Me.chkJointVen.AutoSize = True
        Me.chkJointVen.Location = New System.Drawing.Point(10, 191)
        Me.chkJointVen.Name = "chkJointVen"
        Me.chkJointVen.Size = New System.Drawing.Size(96, 19)
        Me.chkJointVen.TabIndex = 4
        Me.chkJointVen.Text = "Joint Venture"
        Me.chkJointVen.UseVisualStyleBackColor = True
        '
        'chkCC
        '
        Me.chkCC.AutoSize = True
        Me.chkCC.Location = New System.Drawing.Point(10, 165)
        Me.chkCC.Name = "chkCC"
        Me.chkCC.Size = New System.Drawing.Size(157, 19)
        Me.chkCC.TabIndex = 3
        Me.chkCC.Text = "Closed Corporation (CC)"
        Me.chkCC.UseVisualStyleBackColor = True
        '
        'chkPrivCoLtd
        '
        Me.chkPrivCoLtd.AutoSize = True
        Me.chkPrivCoLtd.Location = New System.Drawing.Point(10, 139)
        Me.chkPrivCoLtd.Name = "chkPrivCoLtd"
        Me.chkPrivCoLtd.Size = New System.Drawing.Size(165, 19)
        Me.chkPrivCoLtd.TabIndex = 2
        Me.chkPrivCoLtd.Text = "Private company (Pty) Ltd"
        Me.chkPrivCoLtd.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(23, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 45)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Type of firm:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Please tick all aplicable"
        '
        'chkPubCoLtd
        '
        Me.chkPubCoLtd.AutoSize = True
        Me.chkPubCoLtd.Location = New System.Drawing.Point(10, 114)
        Me.chkPubCoLtd.Name = "chkPubCoLtd"
        Me.chkPubCoLtd.Size = New System.Drawing.Size(142, 19)
        Me.chkPubCoLtd.TabIndex = 0
        Me.chkPubCoLtd.Text = "Public Company (Ltd)"
        Me.chkPubCoLtd.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(119, 483)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(131, 23)
        Me.btnNext.TabIndex = 1
        Me.btnNext.Text = "Next >>"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(12, 483)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(99, 23)
        Me.btnBack.TabIndex = 2
        Me.btnBack.Text = "<< Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'frmSupplierGroupDetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(262, 518)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.grbGroupDetail)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmSupplierGroupDetail"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Supplier Grouping Detail"
        Me.grbGroupDetail.ResumeLayout(False)
        Me.grbGroupDetail.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grbGroupDetail As System.Windows.Forms.GroupBox
    Friend WithEvents chkOther As System.Windows.Forms.CheckBox
    Friend WithEvents chkGovPar As System.Windows.Forms.CheckBox
    Friend WithEvents chkSec21Co As System.Windows.Forms.CheckBox
    Friend WithEvents chkTrust As System.Windows.Forms.CheckBox
    Friend WithEvents chkPartnership As System.Windows.Forms.CheckBox
    Friend WithEvents chkForeign As System.Windows.Forms.CheckBox
    Friend WithEvents chkSolePro As System.Windows.Forms.CheckBox
    Friend WithEvents chkConsortium As System.Windows.Forms.CheckBox
    Friend WithEvents chkJointVen As System.Windows.Forms.CheckBox
    Friend WithEvents chkCC As System.Windows.Forms.CheckBox
    Friend WithEvents chkPrivCoLtd As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkPubCoLtd As System.Windows.Forms.CheckBox
    Friend WithEvents txtOther As System.Windows.Forms.TextBox
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents lblSpecify As System.Windows.Forms.Label
    Friend WithEvents btnBack As System.Windows.Forms.Button
End Class
