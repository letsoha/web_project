﻿Public Class frmSupplierDetails

    Private Sub SupplierDetailsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.SupplierDetailsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.SupplierDetails)

    End Sub

    Private Sub frmSupplierDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Hide all group boxes on form load
        grbDetail_SupplierDetails.Visible = False
        grbDetail_PostalAddr.Visible = False
        grbDetail_PhysicalAddr.Visible = False
        grbDetail_PrefSite.Visible = False
        grbDetail_MoreInfo.Visible = False
        grbDetail_Classification.Visible = -False

        'Set all controls as Read Only
        grbDetail_SupplierDetails.Enabled = False
        grbDetail_PostalAddr.Enabled = False
        grbDetail_PhysicalAddr.Enabled = False
        grbDetail_PrefSite.Enabled = False
        grbDetail_MoreInfo.Enabled = False
        grbDetail_Classification.Enabled = False

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class