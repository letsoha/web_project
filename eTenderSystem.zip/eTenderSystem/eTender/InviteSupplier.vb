﻿Imports System.Net.Mail

Public Class frmInviteSupplier

    Dim SystemProcesses As New eTenderClass
    Dim strSuppContactEmail As String
    Dim dsSuppDetails As New DataSet
    Dim dsSuppEmail As New DataSet
    Dim strSuppRegNum As String
    Dim strSuppName As String

    Private Sub frmInviteSupplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim dsTenderDetails As New DataSet
        Dim myConn As String


        Dim strSuppMainContact As String

        Dim strTenderID As String
        Dim count As Integer

        btnSendInvite.Enabled = False

        myConn = SystemProcesses.GetConnection()

        If myConn <> "true" Then
            MsgBox("There was no connection to Database System. Contact Administrator.", MsgBoxStyle.Exclamation)
        Else
            dsSuppDetails = SystemProcesses.GetSupplierDetails()
            dsTenderDetails = SystemProcesses.GetTenderDetails()


            If dsSuppDetails.Tables("SupplierDetails").Rows.Count = 0 Then
                MsgBox("Error getting Supplier Details from dtabase", MsgBoxStyle.Critical)
            Else
                For count = 0 To dsSuppDetails.Tables("SupplierDetails").Rows.Count - 1
                    strSuppName = dsSuppDetails.Tables("SupplierDetails").Rows(count).Item("sup_CoName")
                    cmbSupplierName.Items.Add(strSuppName)
                Next count
                cmbSupplierName.SelectedIndex = 0

                If dsTenderDetails.Tables("TenderDetails").Rows.Count = 0 Then
                    MsgBox("Error getting Tender Details from database.", MsgBoxStyle.Critical)
                Else
                    For count = 0 To dsTenderDetails.Tables("TenderDetails").Rows.Count - 1
                        strTenderID = dsTenderDetails.Tables("TenderDetails").Rows(count).Item("TenderNotice")
                        cmbTenderNotice.Items.Add(strTenderID)
                    Next
                    cmbTenderNotice.SelectedIndex = 0
                End If
            End If
        End If
    End Sub

    Private Sub btnAddToList_Click(sender As Object, e As EventArgs) Handles btnAddToList.Click
        lstSuppliers.Items.Add(cmbSupplierName.SelectedItem & vbTab & vbTab & cmbTenderNotice.SelectedItem)
        btnSendInvite.Enabled = True
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        lstSuppliers.Items.Remove(lstSuppliers.SelectedItem)

    End Sub

    Private Sub btnSendInvite_Click(sender As Object, e As EventArgs) Handles btnSendInvite.Click
        dsSuppEmail = SystemProcesses.GetSupplierEmail(cmbSupplierName.SelectedItem)
        Dim supEmail As String
        Dim msg As String

        supEmail = dsSuppEmail.Tables("SupplierEmail").Rows(0).Item("sup_MainContactPersonEmail")
        Try
            If btnSendInvite.Text = "Send Invitation" Then
                Dim SmtpServer As New SmtpClient("smtp.gmail.com", 587)
                Dim mail As New MailMessage("letsoha@gmail.com", supEmail, "Invitation to bid for a Tender: " & cmbTenderNotice.SelectedItem, "Dear Supplier" & vbNewLine & vbNewLine & "You are invited for the abovementioned tender in the subject line.")
                SmtpServer.EnableSsl = True
                SmtpServer.Credentials = New Net.NetworkCredential("letsoha", "letsoha0928")
                SmtpServer.Send(mail)
                MsgBox("Invitation sent.", MsgBoxStyle.Information)
                btnSendInvite.Text = "Finish"
            Else
                If btnSendInvite.Text = "Finish" Then
                    Me.Close()
                End If
            End If

        Catch ex As Exception
            msg = ex.Message.ToString()
            MsgBox("Invitation not sent.", MsgBoxStyle.Information)
        End Try
    End Sub
End Class