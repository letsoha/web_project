﻿Public Class frmNewUser
    Dim usrFuncs As New eTenderClass

    Private Sub btnCreateUser_Click(sender As Object, e As EventArgs) Handles btnCreateUser.Click
        Dim myConn As String
        Dim dsUser As String

        myConn = usrFuncs.GetConnection()

        If myConn <> "true" Then
            MsgBox("No connection to database. Contact Administrator.", MsgBoxStyle.Critical)
        Else
            If txtPassword.Text <> txtConfirmPasswd.Text Then
                MsgBox("Password does not match.", MsgBoxStyle.Information)
                txtPassword.Clear()
                txtConfirmPasswd.Clear()
                txtPassword.Focus()
            Else
                dsUser = usrFuncs.AddNewUser(txtUsername.Text, txtPassword.Text, cmbAccess.SelectedItem)
                If dsUser <> "true" Then
                    MsgBox("User Account not created.", MsgBoxStyle.Information)
                Else
                    MsgBox("User Account created successfully.", MsgBoxStyle.Information)
                    Me.Close()
                End If
            End If


        End If
    End Sub

    Private Sub frmNewUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = frmMainForm
        Me.Show()
    End Sub
End Class