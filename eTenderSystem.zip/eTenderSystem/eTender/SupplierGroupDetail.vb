﻿Public Class frmSupplierGroupDetail

    Private Sub frmSupplierGroupDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtOther.Visible = False
        lblSpecify.Visible = False
    End Sub

    Private Sub chkOther_CheckedChanged(sender As Object, e As EventArgs) Handles chkOther.CheckedChanged
        If chkOther.Checked = True Then
            txtOther.Visible = True
            lblSpecify.Visible = True
        Else
            txtOther.Visible = False
            lblSpecify.Visible = False
        End If
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        frmSupplierMainContact.MdiParent = frmMainForm
        Me.Hide()
        frmSupplierMainContact.Show()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        frmNewSupplier.Show()
    End Sub
End Class