﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBidWinner
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grbWinner = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSupplierName = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblTenderName = New System.Windows.Forms.Label()
        Me.tcSalesPerson = New System.Windows.Forms.TabPage()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSalesNameWinner = New System.Windows.Forms.TextBox()
        Me.txtSalesPositionWinner = New System.Windows.Forms.TextBox()
        Me.txtSalesCellWinner = New System.Windows.Forms.TextBox()
        Me.txtSalesFaxWinner = New System.Windows.Forms.TextBox()
        Me.txtSalesEmailWinner = New System.Windows.Forms.TextBox()
        Me.tpMainContact = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtMainNameWinner = New System.Windows.Forms.TextBox()
        Me.txtMainPositionWinner = New System.Windows.Forms.TextBox()
        Me.txtMainCellWinner = New System.Windows.Forms.TextBox()
        Me.txtMainFaxWinner = New System.Windows.Forms.TextBox()
        Me.txtMainEmailWinner = New System.Windows.Forms.TextBox()
        Me.tcMainContact = New System.Windows.Forms.TabControl()
        Me.btnNotification = New System.Windows.Forms.Button()
        Me.grbWinner.SuspendLayout()
        Me.tcSalesPerson.SuspendLayout()
        Me.tpMainContact.SuspendLayout()
        Me.tcMainContact.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbWinner
        '
        Me.grbWinner.Controls.Add(Me.lblTenderName)
        Me.grbWinner.Controls.Add(Me.Label3)
        Me.grbWinner.Controls.Add(Me.lblSupplierName)
        Me.grbWinner.Controls.Add(Me.Label1)
        Me.grbWinner.Location = New System.Drawing.Point(13, 13)
        Me.grbWinner.Name = "grbWinner"
        Me.grbWinner.Size = New System.Drawing.Size(436, 110)
        Me.grbWinner.TabIndex = 0
        Me.grbWinner.TabStop = False
        Me.grbWinner.Text = "Bid Winner"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Supplier:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSupplierName
        '
        Me.lblSupplierName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSupplierName.Location = New System.Drawing.Point(79, 31)
        Me.lblSupplierName.Name = "lblSupplierName"
        Me.lblSupplierName.Size = New System.Drawing.Size(262, 23)
        Me.lblSupplierName.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(9, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Tender:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTenderName
        '
        Me.lblTenderName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTenderName.Location = New System.Drawing.Point(79, 73)
        Me.lblTenderName.Name = "lblTenderName"
        Me.lblTenderName.Size = New System.Drawing.Size(262, 23)
        Me.lblTenderName.TabIndex = 3
        '
        'tcSalesPerson
        '
        Me.tcSalesPerson.Controls.Add(Me.txtSalesEmailWinner)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesFaxWinner)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesCellWinner)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesPositionWinner)
        Me.tcSalesPerson.Controls.Add(Me.txtSalesNameWinner)
        Me.tcSalesPerson.Controls.Add(Me.Label6)
        Me.tcSalesPerson.Controls.Add(Me.Label7)
        Me.tcSalesPerson.Controls.Add(Me.Label8)
        Me.tcSalesPerson.Controls.Add(Me.Label9)
        Me.tcSalesPerson.Controls.Add(Me.Label10)
        Me.tcSalesPerson.Location = New System.Drawing.Point(4, 22)
        Me.tcSalesPerson.Name = "tcSalesPerson"
        Me.tcSalesPerson.Padding = New System.Windows.Forms.Padding(3)
        Me.tcSalesPerson.Size = New System.Drawing.Size(428, 171)
        Me.tcSalesPerson.TabIndex = 1
        Me.tcSalesPerson.Text = "Sales Person"
        Me.tcSalesPerson.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(7, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(135, 25)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Name:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(6, 42)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(135, 25)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Company Position:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(6, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(135, 25)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Cellphone Number:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(6, 101)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(135, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Fax:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(6, 130)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(135, 25)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Email Address:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSalesNameWinner
        '
        Me.txtSalesNameWinner.Location = New System.Drawing.Point(149, 9)
        Me.txtSalesNameWinner.Name = "txtSalesNameWinner"
        Me.txtSalesNameWinner.Size = New System.Drawing.Size(250, 20)
        Me.txtSalesNameWinner.TabIndex = 15
        '
        'txtSalesPositionWinner
        '
        Me.txtSalesPositionWinner.Location = New System.Drawing.Point(149, 42)
        Me.txtSalesPositionWinner.Name = "txtSalesPositionWinner"
        Me.txtSalesPositionWinner.Size = New System.Drawing.Size(250, 20)
        Me.txtSalesPositionWinner.TabIndex = 16
        '
        'txtSalesCellWinner
        '
        Me.txtSalesCellWinner.Location = New System.Drawing.Point(148, 73)
        Me.txtSalesCellWinner.Name = "txtSalesCellWinner"
        Me.txtSalesCellWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtSalesCellWinner.TabIndex = 17
        '
        'txtSalesFaxWinner
        '
        Me.txtSalesFaxWinner.Location = New System.Drawing.Point(148, 103)
        Me.txtSalesFaxWinner.Name = "txtSalesFaxWinner"
        Me.txtSalesFaxWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtSalesFaxWinner.TabIndex = 18
        '
        'txtSalesEmailWinner
        '
        Me.txtSalesEmailWinner.Location = New System.Drawing.Point(148, 133)
        Me.txtSalesEmailWinner.Name = "txtSalesEmailWinner"
        Me.txtSalesEmailWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtSalesEmailWinner.TabIndex = 19
        '
        'tpMainContact
        '
        Me.tpMainContact.Controls.Add(Me.txtMainEmailWinner)
        Me.tpMainContact.Controls.Add(Me.txtMainFaxWinner)
        Me.tpMainContact.Controls.Add(Me.txtMainCellWinner)
        Me.tpMainContact.Controls.Add(Me.txtMainPositionWinner)
        Me.tpMainContact.Controls.Add(Me.txtMainNameWinner)
        Me.tpMainContact.Controls.Add(Me.Label13)
        Me.tpMainContact.Controls.Add(Me.Label14)
        Me.tpMainContact.Controls.Add(Me.Label2)
        Me.tpMainContact.Controls.Add(Me.Label4)
        Me.tpMainContact.Controls.Add(Me.Label5)
        Me.tpMainContact.Location = New System.Drawing.Point(4, 22)
        Me.tpMainContact.Name = "tpMainContact"
        Me.tpMainContact.Padding = New System.Windows.Forms.Padding(3)
        Me.tpMainContact.Size = New System.Drawing.Size(428, 171)
        Me.tpMainContact.TabIndex = 0
        Me.tpMainContact.Text = "Main Contact Person"
        Me.tpMainContact.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(7, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(135, 25)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Name:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(6, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(135, 25)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Company Position:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(6, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(135, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Cellphone Number:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(6, 101)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(135, 25)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "Fax:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(6, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(135, 25)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Email Address:"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtMainNameWinner
        '
        Me.txtMainNameWinner.Location = New System.Drawing.Point(149, 9)
        Me.txtMainNameWinner.Name = "txtMainNameWinner"
        Me.txtMainNameWinner.Size = New System.Drawing.Size(250, 20)
        Me.txtMainNameWinner.TabIndex = 5
        '
        'txtMainPositionWinner
        '
        Me.txtMainPositionWinner.Location = New System.Drawing.Point(149, 42)
        Me.txtMainPositionWinner.Name = "txtMainPositionWinner"
        Me.txtMainPositionWinner.Size = New System.Drawing.Size(250, 20)
        Me.txtMainPositionWinner.TabIndex = 6
        '
        'txtMainCellWinner
        '
        Me.txtMainCellWinner.Location = New System.Drawing.Point(148, 73)
        Me.txtMainCellWinner.Name = "txtMainCellWinner"
        Me.txtMainCellWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtMainCellWinner.TabIndex = 7
        '
        'txtMainFaxWinner
        '
        Me.txtMainFaxWinner.Location = New System.Drawing.Point(148, 103)
        Me.txtMainFaxWinner.Name = "txtMainFaxWinner"
        Me.txtMainFaxWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtMainFaxWinner.TabIndex = 8
        '
        'txtMainEmailWinner
        '
        Me.txtMainEmailWinner.Location = New System.Drawing.Point(148, 133)
        Me.txtMainEmailWinner.Name = "txtMainEmailWinner"
        Me.txtMainEmailWinner.Size = New System.Drawing.Size(251, 20)
        Me.txtMainEmailWinner.TabIndex = 9
        '
        'tcMainContact
        '
        Me.tcMainContact.Controls.Add(Me.tpMainContact)
        Me.tcMainContact.Controls.Add(Me.tcSalesPerson)
        Me.tcMainContact.Location = New System.Drawing.Point(13, 129)
        Me.tcMainContact.Name = "tcMainContact"
        Me.tcMainContact.SelectedIndex = 0
        Me.tcMainContact.Size = New System.Drawing.Size(436, 197)
        Me.tcMainContact.TabIndex = 1
        '
        'btnNotification
        '
        Me.btnNotification.Location = New System.Drawing.Point(13, 333)
        Me.btnNotification.Name = "btnNotification"
        Me.btnNotification.Size = New System.Drawing.Size(145, 23)
        Me.btnNotification.TabIndex = 2
        Me.btnNotification.Text = "Send Notification"
        Me.btnNotification.UseVisualStyleBackColor = True
        '
        'frmBidWinner
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(461, 375)
        Me.Controls.Add(Me.btnNotification)
        Me.Controls.Add(Me.tcMainContact)
        Me.Controls.Add(Me.grbWinner)
        Me.Name = "frmBidWinner"
        Me.Text = "Bid Winner"
        Me.grbWinner.ResumeLayout(False)
        Me.tcSalesPerson.ResumeLayout(False)
        Me.tcSalesPerson.PerformLayout()
        Me.tpMainContact.ResumeLayout(False)
        Me.tpMainContact.PerformLayout()
        Me.tcMainContact.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grbWinner As System.Windows.Forms.GroupBox
    Friend WithEvents lblTenderName As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblSupplierName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tcSalesPerson As System.Windows.Forms.TabPage
    Friend WithEvents txtSalesEmailWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesFaxWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesCellWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesPositionWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesNameWinner As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tpMainContact As System.Windows.Forms.TabPage
    Friend WithEvents txtMainEmailWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtMainFaxWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtMainCellWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtMainPositionWinner As System.Windows.Forms.TextBox
    Friend WithEvents txtMainNameWinner As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tcMainContact As System.Windows.Forms.TabControl
    Friend WithEvents btnNotification As System.Windows.Forms.Button
End Class
