﻿Public Class frmSupplierMainContact

    Private Sub frmSupplierMainContact_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class