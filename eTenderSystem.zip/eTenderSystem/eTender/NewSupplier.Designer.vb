﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewSupplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grbSupplierDetails = New System.Windows.Forms.GroupBox()
        Me.txtTollFree = New System.Windows.Forms.TextBox()
        Me.TollFree = New System.Windows.Forms.Label()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtWebAddr = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtIncTaxNo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtVATNumber = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtRegNumber = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSupplierName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grbPostalAddr = New System.Windows.Forms.GroupBox()
        Me.txtPostalCode = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.rtbPostal = New System.Windows.Forms.RichTextBox()
        Me.grbPhysicalAddr = New System.Windows.Forms.GroupBox()
        Me.txtPhysicalCode = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.rtbPhysical = New System.Windows.Forms.RichTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbCollegeSite = New System.Windows.Forms.ComboBox()
        Me.btnSaveCont = New System.Windows.Forms.Button()
        Me.grbPrefSite = New System.Windows.Forms.GroupBox()
        Me.chkDistributer = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.chkSales = New System.Windows.Forms.CheckBox()
        Me.chkExporter = New System.Windows.Forms.CheckBox()
        Me.chkDistributor = New System.Windows.Forms.CheckBox()
        Me.chkBlackOwned = New System.Windows.Forms.CheckBox()
        Me.chkRepairs = New System.Windows.Forms.CheckBox()
        Me.chkManufacturer = New System.Windows.Forms.CheckBox()
        Me.chkServices = New System.Windows.Forms.CheckBox()
        Me.chkImporter = New System.Windows.Forms.CheckBox()
        Me.chkISO = New System.Windows.Forms.CheckBox()
        Me.grbTaxCert = New System.Windows.Forms.GroupBox()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.btnUploadTaxCert = New System.Windows.Forms.Button()
        Me.dtpExpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.DirectoryEntry1 = New System.DirectoryServices.DirectoryEntry()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.grbSupplierDetails.SuspendLayout()
        Me.grbPostalAddr.SuspendLayout()
        Me.grbPhysicalAddr.SuspendLayout()
        Me.grbPrefSite.SuspendLayout()
        Me.chkDistributer.SuspendLayout()
        Me.grbTaxCert.SuspendLayout()
        Me.SuspendLayout()
        '
        'grbSupplierDetails
        '
        Me.grbSupplierDetails.BackColor = System.Drawing.SystemColors.Info
        Me.grbSupplierDetails.Controls.Add(Me.txtTollFree)
        Me.grbSupplierDetails.Controls.Add(Me.TollFree)
        Me.grbSupplierDetails.Controls.Add(Me.txtFax)
        Me.grbSupplierDetails.Controls.Add(Me.Label8)
        Me.grbSupplierDetails.Controls.Add(Me.txtTelephone)
        Me.grbSupplierDetails.Controls.Add(Me.Label7)
        Me.grbSupplierDetails.Controls.Add(Me.txtEmail)
        Me.grbSupplierDetails.Controls.Add(Me.Label6)
        Me.grbSupplierDetails.Controls.Add(Me.txtWebAddr)
        Me.grbSupplierDetails.Controls.Add(Me.Label5)
        Me.grbSupplierDetails.Controls.Add(Me.txtIncTaxNo)
        Me.grbSupplierDetails.Controls.Add(Me.Label4)
        Me.grbSupplierDetails.Controls.Add(Me.txtVATNumber)
        Me.grbSupplierDetails.Controls.Add(Me.Label3)
        Me.grbSupplierDetails.Controls.Add(Me.txtRegNumber)
        Me.grbSupplierDetails.Controls.Add(Me.Label2)
        Me.grbSupplierDetails.Controls.Add(Me.txtSupplierName)
        Me.grbSupplierDetails.Controls.Add(Me.Label1)
        Me.grbSupplierDetails.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbSupplierDetails.Location = New System.Drawing.Point(13, 13)
        Me.grbSupplierDetails.Name = "grbSupplierDetails"
        Me.grbSupplierDetails.Size = New System.Drawing.Size(506, 309)
        Me.grbSupplierDetails.TabIndex = 0
        Me.grbSupplierDetails.TabStop = False
        Me.grbSupplierDetails.Text = "Supplier Details"
        '
        'txtTollFree
        '
        Me.txtTollFree.Location = New System.Drawing.Point(195, 275)
        Me.txtTollFree.Name = "txtTollFree"
        Me.txtTollFree.Size = New System.Drawing.Size(294, 23)
        Me.txtTollFree.TabIndex = 9
        '
        'TollFree
        '
        Me.TollFree.Location = New System.Drawing.Point(10, 270)
        Me.TollFree.Name = "TollFree"
        Me.TollFree.Size = New System.Drawing.Size(176, 22)
        Me.TollFree.TabIndex = 16
        Me.TollFree.Text = "Toll Free:"
        Me.TollFree.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(195, 245)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(294, 23)
        Me.txtFax.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(10, 242)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(176, 26)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Fax No.:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTelephone
        '
        Me.txtTelephone.Location = New System.Drawing.Point(195, 215)
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(294, 23)
        Me.txtTelephone.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(7, 215)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 23)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Telephone No.:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(195, 182)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(294, 23)
        Me.txtEmail.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(10, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(176, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Email:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtWebAddr
        '
        Me.txtWebAddr.Location = New System.Drawing.Point(195, 152)
        Me.txtWebAddr.Name = "txtWebAddr"
        Me.txtWebAddr.Size = New System.Drawing.Size(294, 23)
        Me.txtWebAddr.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(10, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(176, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Web Address:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtIncTaxNo
        '
        Me.txtIncTaxNo.Location = New System.Drawing.Point(195, 122)
        Me.txtIncTaxNo.Name = "txtIncTaxNo"
        Me.txtIncTaxNo.Size = New System.Drawing.Size(294, 23)
        Me.txtIncTaxNo.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(10, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(176, 26)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Income Tax Ref. No.:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtVATNumber
        '
        Me.txtVATNumber.Location = New System.Drawing.Point(195, 92)
        Me.txtVATNumber.Name = "txtVATNumber"
        Me.txtVATNumber.Size = New System.Drawing.Size(294, 23)
        Me.txtVATNumber.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(7, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(179, 28)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "VAT Registration No.:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtRegNumber
        '
        Me.txtRegNumber.Location = New System.Drawing.Point(195, 64)
        Me.txtRegNumber.Name = "txtRegNumber"
        Me.txtRegNumber.Size = New System.Drawing.Size(294, 23)
        Me.txtRegNumber.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(7, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(179, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Company/CC Registration No.:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSupplierName
        '
        Me.txtSupplierName.Location = New System.Drawing.Point(195, 34)
        Me.txtSupplierName.Name = "txtSupplierName"
        Me.txtSupplierName.Size = New System.Drawing.Size(294, 23)
        Me.txtSupplierName.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(7, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Supplier Name:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grbPostalAddr
        '
        Me.grbPostalAddr.BackColor = System.Drawing.SystemColors.Info
        Me.grbPostalAddr.Controls.Add(Me.txtPostalCode)
        Me.grbPostalAddr.Controls.Add(Me.Label9)
        Me.grbPostalAddr.Controls.Add(Me.rtbPostal)
        Me.grbPostalAddr.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbPostalAddr.Location = New System.Drawing.Point(13, 329)
        Me.grbPostalAddr.Name = "grbPostalAddr"
        Me.grbPostalAddr.Size = New System.Drawing.Size(228, 181)
        Me.grbPostalAddr.TabIndex = 1
        Me.grbPostalAddr.TabStop = False
        Me.grbPostalAddr.Text = "Postal Address"
        '
        'txtPostalCode
        '
        Me.txtPostalCode.Location = New System.Drawing.Point(55, 120)
        Me.txtPostalCode.Name = "txtPostalCode"
        Me.txtPostalCode.Size = New System.Drawing.Size(61, 23)
        Me.txtPostalCode.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(7, 121)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 23)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Code:"
        '
        'rtbPostal
        '
        Me.rtbPostal.Location = New System.Drawing.Point(7, 20)
        Me.rtbPostal.Name = "rtbPostal"
        Me.rtbPostal.Size = New System.Drawing.Size(215, 94)
        Me.rtbPostal.TabIndex = 10
        Me.rtbPostal.Text = ""
        '
        'grbPhysicalAddr
        '
        Me.grbPhysicalAddr.BackColor = System.Drawing.SystemColors.Info
        Me.grbPhysicalAddr.Controls.Add(Me.txtPhysicalCode)
        Me.grbPhysicalAddr.Controls.Add(Me.Label10)
        Me.grbPhysicalAddr.Controls.Add(Me.rtbPhysical)
        Me.grbPhysicalAddr.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbPhysicalAddr.Location = New System.Drawing.Point(264, 329)
        Me.grbPhysicalAddr.Name = "grbPhysicalAddr"
        Me.grbPhysicalAddr.Size = New System.Drawing.Size(255, 181)
        Me.grbPhysicalAddr.TabIndex = 2
        Me.grbPhysicalAddr.TabStop = False
        Me.grbPhysicalAddr.Text = "Physical Address"
        '
        'txtPhysicalCode
        '
        Me.txtPhysicalCode.Location = New System.Drawing.Point(61, 120)
        Me.txtPhysicalCode.Name = "txtPhysicalCode"
        Me.txtPhysicalCode.Size = New System.Drawing.Size(61, 23)
        Me.txtPhysicalCode.TabIndex = 13
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(11, 121)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 23)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Code:"
        '
        'rtbPhysical
        '
        Me.rtbPhysical.Location = New System.Drawing.Point(7, 20)
        Me.rtbPhysical.Name = "rtbPhysical"
        Me.rtbPhysical.Size = New System.Drawing.Size(242, 94)
        Me.rtbPhysical.TabIndex = 12
        Me.rtbPhysical.Text = ""
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(9, 34)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(110, 18)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Preferred College Site:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbCollegeSite
        '
        Me.cmbCollegeSite.FormattingEnabled = True
        Me.cmbCollegeSite.Items.AddRange(New Object() {"Corporate Centre", "Jouberton", "Klerksdorp", "Matlosana", "Potchefstroom", "Taung", "Wolmaranstad"})
        Me.cmbCollegeSite.Location = New System.Drawing.Point(125, 34)
        Me.cmbCollegeSite.Name = "cmbCollegeSite"
        Me.cmbCollegeSite.Size = New System.Drawing.Size(166, 23)
        Me.cmbCollegeSite.TabIndex = 14
        Me.cmbCollegeSite.Text = "--- Select ---"
        '
        'btnSaveCont
        '
        Me.btnSaveCont.Location = New System.Drawing.Point(526, 516)
        Me.btnSaveCont.Name = "btnSaveCont"
        Me.btnSaveCont.Size = New System.Drawing.Size(182, 28)
        Me.btnSaveCont.TabIndex = 24
        Me.btnSaveCont.Text = "Save and Continue >>"
        Me.btnSaveCont.UseVisualStyleBackColor = True
        '
        'grbPrefSite
        '
        Me.grbPrefSite.BackColor = System.Drawing.SystemColors.Info
        Me.grbPrefSite.Controls.Add(Me.cmbCollegeSite)
        Me.grbPrefSite.Controls.Add(Me.Label11)
        Me.grbPrefSite.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbPrefSite.Location = New System.Drawing.Point(526, 13)
        Me.grbPrefSite.Name = "grbPrefSite"
        Me.grbPrefSite.Size = New System.Drawing.Size(298, 66)
        Me.grbPrefSite.TabIndex = 18
        Me.grbPrefSite.TabStop = False
        Me.grbPrefSite.Text = "Preferred College Site"
        '
        'chkDistributer
        '
        Me.chkDistributer.BackColor = System.Drawing.SystemColors.Info
        Me.chkDistributer.Controls.Add(Me.Label13)
        Me.chkDistributer.Controls.Add(Me.chkSales)
        Me.chkDistributer.Controls.Add(Me.chkExporter)
        Me.chkDistributer.Controls.Add(Me.chkDistributor)
        Me.chkDistributer.Controls.Add(Me.chkBlackOwned)
        Me.chkDistributer.Controls.Add(Me.chkRepairs)
        Me.chkDistributer.Controls.Add(Me.chkManufacturer)
        Me.chkDistributer.Controls.Add(Me.chkServices)
        Me.chkDistributer.Controls.Add(Me.chkImporter)
        Me.chkDistributer.Controls.Add(Me.chkISO)
        Me.chkDistributer.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkDistributer.Location = New System.Drawing.Point(526, 86)
        Me.chkDistributer.Name = "chkDistributer"
        Me.chkDistributer.Size = New System.Drawing.Size(298, 268)
        Me.chkDistributer.TabIndex = 19
        Me.chkDistributer.TabStop = False
        Me.chkDistributer.Text = "Company / Supplier Classification"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(12, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(204, 13)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Please select ALL relevant options"
        '
        'chkSales
        '
        Me.chkSales.AutoSize = True
        Me.chkSales.Location = New System.Drawing.Point(12, 241)
        Me.chkSales.Name = "chkSales"
        Me.chkSales.Size = New System.Drawing.Size(55, 19)
        Me.chkSales.TabIndex = 23
        Me.chkSales.Text = "Sales"
        Me.chkSales.UseVisualStyleBackColor = True
        '
        'chkExporter
        '
        Me.chkExporter.AutoSize = True
        Me.chkExporter.Location = New System.Drawing.Point(12, 220)
        Me.chkExporter.Name = "chkExporter"
        Me.chkExporter.Size = New System.Drawing.Size(72, 19)
        Me.chkExporter.TabIndex = 22
        Me.chkExporter.Text = "Exporter"
        Me.chkExporter.UseVisualStyleBackColor = True
        '
        'chkDistributor
        '
        Me.chkDistributor.AutoSize = True
        Me.chkDistributor.Location = New System.Drawing.Point(12, 196)
        Me.chkDistributor.Name = "chkDistributor"
        Me.chkDistributor.Size = New System.Drawing.Size(86, 19)
        Me.chkDistributor.TabIndex = 21
        Me.chkDistributor.Text = "Distributer"
        Me.chkDistributor.UseVisualStyleBackColor = True
        '
        'chkBlackOwned
        '
        Me.chkBlackOwned.AutoSize = True
        Me.chkBlackOwned.Location = New System.Drawing.Point(12, 172)
        Me.chkBlackOwned.Name = "chkBlackOwned"
        Me.chkBlackOwned.Size = New System.Drawing.Size(97, 19)
        Me.chkBlackOwned.TabIndex = 20
        Me.chkBlackOwned.Text = "Black Owned"
        Me.chkBlackOwned.UseVisualStyleBackColor = True
        '
        'chkRepairs
        '
        Me.chkRepairs.AutoSize = True
        Me.chkRepairs.Location = New System.Drawing.Point(12, 148)
        Me.chkRepairs.Name = "chkRepairs"
        Me.chkRepairs.Size = New System.Drawing.Size(68, 19)
        Me.chkRepairs.TabIndex = 19
        Me.chkRepairs.Text = "Repairs"
        Me.chkRepairs.UseVisualStyleBackColor = True
        '
        'chkManufacturer
        '
        Me.chkManufacturer.AutoSize = True
        Me.chkManufacturer.Location = New System.Drawing.Point(12, 124)
        Me.chkManufacturer.Name = "chkManufacturer"
        Me.chkManufacturer.Size = New System.Drawing.Size(102, 19)
        Me.chkManufacturer.TabIndex = 18
        Me.chkManufacturer.Text = "Manufacturer"
        Me.chkManufacturer.UseVisualStyleBackColor = True
        '
        'chkServices
        '
        Me.chkServices.AutoSize = True
        Me.chkServices.Location = New System.Drawing.Point(12, 100)
        Me.chkServices.Name = "chkServices"
        Me.chkServices.Size = New System.Drawing.Size(71, 19)
        Me.chkServices.TabIndex = 17
        Me.chkServices.Text = "Services"
        Me.chkServices.UseVisualStyleBackColor = True
        '
        'chkImporter
        '
        Me.chkImporter.AutoSize = True
        Me.chkImporter.Location = New System.Drawing.Point(12, 76)
        Me.chkImporter.Name = "chkImporter"
        Me.chkImporter.Size = New System.Drawing.Size(74, 19)
        Me.chkImporter.TabIndex = 16
        Me.chkImporter.Text = "Importer"
        Me.chkImporter.UseVisualStyleBackColor = True
        '
        'chkISO
        '
        Me.chkISO.AutoSize = True
        Me.chkISO.Location = New System.Drawing.Point(12, 52)
        Me.chkISO.Name = "chkISO"
        Me.chkISO.Size = New System.Drawing.Size(80, 19)
        Me.chkISO.TabIndex = 15
        Me.chkISO.Text = "ISO Listed"
        Me.chkISO.UseVisualStyleBackColor = True
        '
        'grbTaxCert
        '
        Me.grbTaxCert.BackColor = System.Drawing.SystemColors.Info
        Me.grbTaxCert.Controls.Add(Me.lblMessage)
        Me.grbTaxCert.Controls.Add(Me.btnUploadTaxCert)
        Me.grbTaxCert.Controls.Add(Me.dtpExpDate)
        Me.grbTaxCert.Controls.Add(Me.Label12)
        Me.grbTaxCert.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbTaxCert.Location = New System.Drawing.Point(526, 361)
        Me.grbTaxCert.Name = "grbTaxCert"
        Me.grbTaxCert.Size = New System.Drawing.Size(298, 149)
        Me.grbTaxCert.TabIndex = 25
        Me.grbTaxCert.TabStop = False
        Me.grbTaxCert.Text = "Attach Tax Clearance Certificate"
        '
        'lblMessage
        '
        Me.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMessage.ForeColor = System.Drawing.Color.Red
        Me.lblMessage.Location = New System.Drawing.Point(15, 52)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(273, 28)
        Me.lblMessage.TabIndex = 27
        '
        'btnUploadTaxCert
        '
        Me.btnUploadTaxCert.Location = New System.Drawing.Point(12, 22)
        Me.btnUploadTaxCert.Name = "btnUploadTaxCert"
        Me.btnUploadTaxCert.Size = New System.Drawing.Size(276, 23)
        Me.btnUploadTaxCert.TabIndex = 26
        Me.btnUploadTaxCert.Text = "Choose Tax Certificate from Computer"
        Me.btnUploadTaxCert.UseVisualStyleBackColor = True
        '
        'dtpExpDate
        '
        Me.dtpExpDate.Location = New System.Drawing.Point(15, 110)
        Me.dtpExpDate.Name = "dtpExpDate"
        Me.dtpExpDate.Size = New System.Drawing.Size(152, 23)
        Me.dtpExpDate.TabIndex = 25
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(12, 90)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(155, 17)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Tax Certificate Expiry Date:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(715, 516)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(109, 28)
        Me.btnCancel.TabIndex = 26
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmNewSupplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(829, 556)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.grbTaxCert)
        Me.Controls.Add(Me.chkDistributer)
        Me.Controls.Add(Me.grbPrefSite)
        Me.Controls.Add(Me.btnSaveCont)
        Me.Controls.Add(Me.grbPhysicalAddr)
        Me.Controls.Add(Me.grbPostalAddr)
        Me.Controls.Add(Me.grbSupplierDetails)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmNewSupplier"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New Supplier"
        Me.grbSupplierDetails.ResumeLayout(False)
        Me.grbSupplierDetails.PerformLayout()
        Me.grbPostalAddr.ResumeLayout(False)
        Me.grbPostalAddr.PerformLayout()
        Me.grbPhysicalAddr.ResumeLayout(False)
        Me.grbPhysicalAddr.PerformLayout()
        Me.grbPrefSite.ResumeLayout(False)
        Me.chkDistributer.ResumeLayout(False)
        Me.chkDistributer.PerformLayout()
        Me.grbTaxCert.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grbSupplierDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtRegNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtSupplierName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtVATNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtIncTaxNo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtWebAddr As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtTollFree As System.Windows.Forms.TextBox
    Friend WithEvents TollFree As System.Windows.Forms.Label
    Friend WithEvents grbPostalAddr As System.Windows.Forms.GroupBox
    Friend WithEvents grbPhysicalAddr As System.Windows.Forms.GroupBox
    Friend WithEvents txtPostalCode As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents rtbPostal As System.Windows.Forms.RichTextBox
    Friend WithEvents txtPhysicalCode As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents rtbPhysical As System.Windows.Forms.RichTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmbCollegeSite As System.Windows.Forms.ComboBox
    Friend WithEvents btnSaveCont As System.Windows.Forms.Button
    Friend WithEvents grbPrefSite As System.Windows.Forms.GroupBox
    Friend WithEvents chkDistributer As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents chkSales As System.Windows.Forms.CheckBox
    Friend WithEvents chkExporter As System.Windows.Forms.CheckBox
    Friend WithEvents chkDistributor As System.Windows.Forms.CheckBox
    Friend WithEvents chkBlackOwned As System.Windows.Forms.CheckBox
    Friend WithEvents chkRepairs As System.Windows.Forms.CheckBox
    Friend WithEvents chkManufacturer As System.Windows.Forms.CheckBox
    Friend WithEvents chkServices As System.Windows.Forms.CheckBox
    Friend WithEvents chkImporter As System.Windows.Forms.CheckBox
    Friend WithEvents chkISO As System.Windows.Forms.CheckBox
    Friend WithEvents grbTaxCert As System.Windows.Forms.GroupBox
    Friend WithEvents DirectoryEntry1 As System.DirectoryServices.DirectoryEntry
    Friend WithEvents dtpExpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnUploadTaxCert As System.Windows.Forms.Button
    Friend WithEvents lblMessage As System.Windows.Forms.Label
End Class
