﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMainForm))
        Me.mnsMainForm = New System.Windows.Forms.MenuStrip()
        Me.mnsFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsNewTender = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsNewSupplier = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsNewUser = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.SupplierDetailsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsManage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsManageTender = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsManageSupplier = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsSupplier = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsActivateSupplier = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsInviteSupplier = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsTools = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsViewWinner = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsLogout = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblUserDetails = New System.Windows.Forms.Label()
        Me.mnsSupplierActivationStatus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnsMainForm.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnsMainForm
        '
        Me.mnsMainForm.AllowItemReorder = True
        Me.mnsMainForm.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.mnsMainForm.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.mnsMainForm.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsFile, Me.mnsManage, Me.mnsSupplier, Me.mnsTools, Me.HelpToolStripMenuItem})
        Me.mnsMainForm.Location = New System.Drawing.Point(0, 0)
        Me.mnsMainForm.Name = "mnsMainForm"
        Me.mnsMainForm.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.mnsMainForm.Size = New System.Drawing.Size(796, 24)
        Me.mnsMainForm.TabIndex = 1
        Me.mnsMainForm.Text = "MenuStrip1"
        '
        'mnsFile
        '
        Me.mnsFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsNew, Me.mnsOpen, Me.toolStripSeparator2, Me.mnsLogout, Me.ExitToolStripMenuItem})
        Me.mnsFile.Name = "mnsFile"
        Me.mnsFile.Size = New System.Drawing.Size(37, 20)
        Me.mnsFile.Text = "&File"
        '
        'mnsNew
        '
        Me.mnsNew.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsNewTender, Me.mnsNewSupplier, Me.mnsNewUser})
        Me.mnsNew.Image = CType(resources.GetObject("mnsNew.Image"), System.Drawing.Image)
        Me.mnsNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnsNew.Name = "mnsNew"
        Me.mnsNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mnsNew.Size = New System.Drawing.Size(152, 22)
        Me.mnsNew.Text = "&New"
        '
        'mnsNewTender
        '
        Me.mnsNewTender.Name = "mnsNewTender"
        Me.mnsNewTender.Size = New System.Drawing.Size(152, 22)
        Me.mnsNewTender.Text = "&Tender"
        '
        'mnsNewSupplier
        '
        Me.mnsNewSupplier.Name = "mnsNewSupplier"
        Me.mnsNewSupplier.Size = New System.Drawing.Size(152, 22)
        Me.mnsNewSupplier.Text = "S&upplier"
        '
        'mnsNewUser
        '
        Me.mnsNewUser.Name = "mnsNewUser"
        Me.mnsNewUser.Size = New System.Drawing.Size(152, 22)
        Me.mnsNewUser.Text = "Us&er"
        '
        'mnsOpen
        '
        Me.mnsOpen.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SupplierDetailsToolStripMenuItem1})
        Me.mnsOpen.Image = CType(resources.GetObject("mnsOpen.Image"), System.Drawing.Image)
        Me.mnsOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnsOpen.Name = "mnsOpen"
        Me.mnsOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnsOpen.Size = New System.Drawing.Size(152, 22)
        Me.mnsOpen.Text = "&Open"
        '
        'SupplierDetailsToolStripMenuItem1
        '
        Me.SupplierDetailsToolStripMenuItem1.Name = "SupplierDetailsToolStripMenuItem1"
        Me.SupplierDetailsToolStripMenuItem1.Size = New System.Drawing.Size(155, 22)
        Me.SupplierDetailsToolStripMenuItem1.Text = "Su&pplier Details"
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(149, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'mnsManage
        '
        Me.mnsManage.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsManageTender, Me.mnsManageSupplier})
        Me.mnsManage.Name = "mnsManage"
        Me.mnsManage.Size = New System.Drawing.Size(62, 20)
        Me.mnsManage.Text = "&Manage"
        '
        'mnsManageTender
        '
        Me.mnsManageTender.Name = "mnsManageTender"
        Me.mnsManageTender.ShortcutKeyDisplayString = "Alt+D"
        Me.mnsManageTender.Size = New System.Drawing.Size(152, 22)
        Me.mnsManageTender.Text = "Ten&der"
        '
        'mnsManageSupplier
        '
        Me.mnsManageSupplier.Name = "mnsManageSupplier"
        Me.mnsManageSupplier.Size = New System.Drawing.Size(152, 22)
        Me.mnsManageSupplier.Text = "Supp&lier"
        '
        'mnsSupplier
        '
        Me.mnsSupplier.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsActivateSupplier, Me.mnsInviteSupplier, Me.mnsSupplierActivationStatus})
        Me.mnsSupplier.Name = "mnsSupplier"
        Me.mnsSupplier.Size = New System.Drawing.Size(110, 20)
        Me.mnsSupplier.Text = "&Supplier Account"
        '
        'mnsActivateSupplier
        '
        Me.mnsActivateSupplier.Name = "mnsActivateSupplier"
        Me.mnsActivateSupplier.Size = New System.Drawing.Size(209, 22)
        Me.mnsActivateSupplier.Text = "Acti&vate Supplier"
        '
        'mnsInviteSupplier
        '
        Me.mnsInviteSupplier.Name = "mnsInviteSupplier"
        Me.mnsInviteSupplier.Size = New System.Drawing.Size(209, 22)
        Me.mnsInviteSupplier.Text = "Invi&te Supplier"
        '
        'mnsTools
        '
        Me.mnsTools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnsViewWinner})
        Me.mnsTools.Name = "mnsTools"
        Me.mnsTools.Size = New System.Drawing.Size(48, 20)
        Me.mnsTools.Text = "&Tools"
        '
        'mnsViewWinner
        '
        Me.mnsViewWinner.Name = "mnsViewWinner"
        Me.mnsViewWinner.Size = New System.Drawing.Size(184, 22)
        Me.mnsViewWinner.Text = "&View Winning Bidder"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(113, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.AboutToolStripMenuItem.Text = "&About..."
        '
        'mnsLogout
        '
        Me.mnsLogout.Name = "mnsLogout"
        Me.mnsLogout.Size = New System.Drawing.Size(152, 22)
        Me.mnsLogout.Text = "&Logout"
        '
        'lblUserDetails
        '
        Me.lblUserDetails.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblUserDetails.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserDetails.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblUserDetails.Location = New System.Drawing.Point(5, 29)
        Me.lblUserDetails.Name = "lblUserDetails"
        Me.lblUserDetails.Size = New System.Drawing.Size(162, 26)
        Me.lblUserDetails.TabIndex = 3
        '
        'mnsSupplierActivationStatus
        '
        Me.mnsSupplierActivationStatus.Name = "mnsSupplierActivationStatus"
        Me.mnsSupplierActivationStatus.Size = New System.Drawing.Size(209, 22)
        Me.mnsSupplierActivationStatus.Text = "Supplier Activation Status"
        '
        'frmMainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(796, 519)
        Me.Controls.Add(Me.lblUserDetails)
        Me.Controls.Add(Me.mnsMainForm)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.mnsMainForm
        Me.Name = "frmMainForm"
        Me.Text = "eTender"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.mnsMainForm.ResumeLayout(False)
        Me.mnsMainForm.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnsMainForm As System.Windows.Forms.MenuStrip
    Friend WithEvents mnsManage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsManageTender As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsManageSupplier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsSupplier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsActivateSupplier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsInviteSupplier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsNew As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsNewTender As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsNewSupplier As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsNewUser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierDetailsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsTools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsViewWinner As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnsLogout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblUserDetails As System.Windows.Forms.Label
    Friend WithEvents mnsSupplierActivationStatus As System.Windows.Forms.ToolStripMenuItem

End Class
