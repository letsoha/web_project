﻿Public Class frmNewSupplier
    Public folder As New OpenFileDialog
    Dim SystemProcesses As New eTenderClass

    Private Sub frmNewSupplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnSaveCont.Click

        Dim myConn As String
        Dim dsSuppDetails As String
        Dim strClass As String = ""

        myConn = SystemProcesses.GetConnection()

        If myConn <> "true" Then
            MessageBox.Show("There was no connection to Database.", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            If chkBlackOwned.Checked = True Then
                strClass = strClass & chkBlackOwned.Text
            End If

            If chkDistributor.Checked = True Then
                strClass = strClass & ", " & chkDistributor.Text
            End If

            If chkExporter.Checked = True Then
                strClass = strClass & ", " & chkExporter.Text
            End If

            If chkISO.Checked = True Then
                strClass = strClass & ", " & chkISO.Text
            End If

            If chkManufacturer.Checked = True Then
                strClass = strClass & ", " & chkManufacturer.Text
            End If

            If chkRepairs.Checked = True Then
                strClass = strClass & ", " & chkRepairs.Text
            End If

            If chkSales.Checked = True Then
                strClass = strClass & ", " & chkSales.Text
            End If

            If chkServices.Checked = True Then
                strClass = strClass & ", " & chkServices.Text
            End If

            dsSuppDetails = SystemProcesses.AddSupplier(txtRegNumber.Text, txtSupplierName.Text, txtVATNumber.Text, txtIncTaxNo.Text, txtWebAddr.Text, txtEmail.Text, txtTelephone.Text, txtFax.Text, txtTollFree.Text, rtbPostal.Text, txtPostalCode.Text, rtbPhysical.Text, txtPhysicalCode.Text, cmbCollegeSite.SelectedItem, strClass, folder.FileName, dtpExpDate.Value)

            If dsSuppDetails <> "true" Then
                MsgBox("Details not added to system.", MsgBoxStyle.Information)
            Else
                MsgBox("Click Ok to continue ....", MsgBoxStyle.Information)
                frmSupplierGroupDetail.MdiParent = frmMainForm
                Me.Hide()
                frmSupplierGroupDetail.Show()
            End If

        End If



    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        If MsgBox("Are you sure you want to cancel this operation? All data already entered will be lost.", MessageBoxButtons.YesNo, "Close window") _
            = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

   
    Private Sub btnUploadTaxCert_Click(sender As Object, e As EventArgs) Handles btnUploadTaxCert.Click
        Dim result = folder.ShowDialog()
        If result = 1 Then
            lblMessage.Text = "File ready to be saved. Click on 'Save and Continue' to proceed."
        Else
            lblMessage.Text = "File not ready to be saved."
        End If
    End Sub
End Class