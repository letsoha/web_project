﻿Imports Microsoft.VisualBasic
Imports System.Data.OleDb
Imports System.Data
Imports System.Data.OleDb.OleDbConnection
Imports System.Data.OleDb.OleDbDataAdapter

Public Class eTenderClass
    Dim myConnection As New OleDbConnection
    Public Function GetConnection() As String
        Dim signal As String = "true"
        Try
            myConnection = New OleDbConnection("PROVIDER=Microsoft.Jet.OLEDB.4.0; DATA Source = C:\Users\James\Documents\Visual Studio 2012\Projects\eTenderSystem\eTender\App_Data\eTenderDB.mdb")
            myConnection.Open()
        Catch ex As Exception
            signal = ex.Message.ToString()
        End Try
        Return signal
    End Function
    Public Function GetUserDetails(ByVal Username As String) As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsUserDetails As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT * FROM Users WHERE (Username = '" + Username + "')"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsUserDetails, "UserDetails")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsUserDetails
    End Function
    Public Function AddTenderDetails(ByVal TenderID As String, ByVal TenderNotice As String, ByVal IssueDate As Date, ByVal ClosingDate As Date, ByVal ClosingTime As Date, ByVal TendDoc As Object) As String
        Dim sql As String
        Dim cmd As OleDb.OleDbCommand
        Dim result As String = "true"


        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        Try
            sql = "INSERT INTO Tender (TenderID, TenderNotice, IssueDate, ClosingDate, ClosingTime, TenderDoc) VALUES ('" + TenderID + "', '" + TenderNotice + "', '" + IssueDate + "', '" + ClosingDate + "', '" + ClosingTime + "', '" + TendDoc + "')"
            cmd = New OleDbCommand(sql, myConnection)

            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            result = ex.Message.ToString()
        End Try

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return result
    End Function
    Public Function GetTenderDocument(ByVal TenderNum As String) As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsTenderDoc As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT TenderDoc FROM Tender WHERE (TenderID = '" + TenderNum + "')"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsTenderDoc, "TenderDoc")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsTenderDoc
    End Function
    Public Function GetSupplierDetails() As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsSupplierDetails As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT sup_RegNumber, sup_CoName, sup_MainContactPersonName, sup_MainContactPersonEmail FROM SupplierDetails"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsSupplierDetails, "SupplierDetails")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsSupplierDetails
    End Function
    Public Function GetSupplierEmail(ByVal SuppName As String) As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsSupplierEmail As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT sup_MainContactPersonEmail FROM SupplierDetails WHERE sup_CoName = '" + SuppName + "'"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsSupplierEmail, "SupplierEmail")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsSupplierEmail
    End Function
    Public Function GetTenderDetails() As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsTenderDetails As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT TenderID, TenderNotice FROM Tender"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsTenderDetails, "TenderDetails")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsTenderDetails
    End Function
    Public Function AddNewUser(ByVal Username As String, ByVal usrPassword As String, ByVal usrAccessType As String) As String
        Dim sql As String
        Dim cmd As OleDb.OleDbCommand
        Dim result As String = "true"


        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        Try
            sql = "INSERT INTO Users (Username, usrPassword, usrAccessType) VALUES ('" + Username + "', '" + usrPassword + "', '" + usrAccessType + "')"
            cmd = New OleDbCommand(sql, myConnection)

            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            result = ex.Message.ToString()
        End Try

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return result
    End Function
    Public Function AddSupplier(ByVal supRegNum As String, ByVal supName As String, ByVal supVat As String, ByVal supTaxNum As String, ByVal supWeb As String, ByVal supEmail As String, ByVal supTel As String, ByVal supFax As String, ByVal supTollFree As String, ByVal supPostalAddr As String, ByVal supPostalCode As String, ByVal supPhysicalAddr As String, ByVal supPhysicalCode As String, ByVal supPrefCollege As String, ByVal supClassification As String, ByVal supTexCert As Object, ByVal supTaxCertExpDate As Date) As String
        Dim sql As String
        Dim cmd As OleDb.OleDbCommand
        Dim result As String = "true"


        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        Try
            sql = "INSERT INTO SupplierDetails (sup_RegNumber, sup_CoName, sup_VATNumber, sup_IncTaxNumber, sup_WebAddress, sup_Email, sup_Tel, sup_Fax, sup_TollFreeNumber, sup_PostalAddr, sup_PhysicalAddr, sup_PostalCode, sup_PhysicalCode, sup_PreferredCollSite, sup_Classification, sup_TaxCert, sup_TaxCertExpDate) VALUES ('" + supRegNum + "', '" + supName + "', '" + supVat + "', '" + supTaxNum + "', '" + supWeb + "', '" + supEmail + "', '" + supTel + "', '" + supFax + "', '" + supTollFree + "', '" + supPostalAddr + "', '" + supPhysicalAddr + "', '" + supPostalCode + "', '" + supPhysicalCode + "', '" + supPrefCollege + "', '" + supClassification + "', '" + supTexCert + "', '" + supTaxCertExpDate + "')"
            cmd = New OleDbCommand(sql, myConnection)

            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            result = ex.Message.ToString()
        End Try

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return result
    End Function
    Public Function UpdateEmpDetails(ByVal EmplNum As String, ByVal FName As String, ByVal SecondName As String, ByVal Surname As String, ByVal Postal As String, ByVal ResAddress As String, ByVal TelHome As String, ByVal Mobile As String, ByVal TelWork As String, ByVal EmergContPerson As String, ByVal EmergContNum As String, ByVal Dept As String, ByVal EmplDate As String) As String
        Dim sql As String
        Dim ds As New DataSet
        Dim cmd As OleDb.OleDbCommand
        Dim result As String = ""
        Try
            sql = "UPDATE EmpDetails SET Empnumber = '" + EmplNum + "', FirstName = '" + FName + "', SecondName = '" + SecondName + "', Surname = '" + Surname + "', PostalAddress = '" + Postal + "', ResidentialAddress = '" + ResAddress + "', TelHome = '" + TelHome + "', ExtWork = '" + TelWork + "', MobileNum = '" + Mobile + "',   EmergencyContactPerson = '" + EmergContPerson + "', EmergencyContactNum = '" + EmergContNum + "', Department = '" + Dept + "', EmploymentDate = '" + EmplDate + "'  WHERE (EmpNumber = '" + EmplNum + "')"
            cmd = New OleDb.OleDbCommand(sql, myConnection)
            If cmd.Connection.State = ConnectionState.Closed Then
                cmd.Connection.Open()
            End If
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()
            If cmd.Connection.State = ConnectionState.Open Then
                cmd.Connection.Close()
            End If
            result = "true"
        Catch ex As Exception
            result = ex.Message.ToString()
        End Try
        Return result
    End Function
    Public Function SearchEmplDetailsSurname(ByVal Surname As String) As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim dsEmplDetails As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If

        sql = "SELECT * FROM EmpDetails WHERE (Surname = '" + Surname + "')"
        da = New OleDb.OleDbDataAdapter(sql, myConnection)
        da.Fill(dsEmplDetails, "EmployeeDetails")

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsEmplDetails
    End Function
    Public Function EmplDetails() As DataSet
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim result As String = "true"
        Dim dsEmplDetails As New DataSet

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If
        Try
            sql = "SELECT * FROM EmpDetails ORDER BY Surname ASC"
            da = New OleDb.OleDbDataAdapter(sql, myConnection)
            da.Fill(dsEmplDetails, "EmpDetails")
        Catch ex As Exception
            result = ex.Message.ToString()
        End Try

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return dsEmplDetails
    End Function
    Public Function DeleteEmpl(ByVal EmplNumber As String) As String
        Dim sql As String
        Dim da As OleDb.OleDbDataAdapter
        Dim result As String = "true"
        Dim cmd As OleDb.OleDbCommand

        If myConnection.State = ConnectionState.Closed Then
            myConnection.Open()
        End If
        Try
            sql = "DELETE FROM EmpDetails WHERE EmpNumber = '" + EmplNumber + "'"
            da = New OleDb.OleDbDataAdapter(sql, myConnection)
            cmd = New OleDbCommand(sql, myConnection)

            cmd.CommandText = sql
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            result = ex.Message.ToString()
        End Try

        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
        End If
        Return result
    End Function
End Class
