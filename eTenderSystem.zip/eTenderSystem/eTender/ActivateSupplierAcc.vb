﻿Public Class frmActivateSupplierAcc

End Class