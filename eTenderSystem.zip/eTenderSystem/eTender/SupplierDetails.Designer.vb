﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSupplierDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbSearchBy = New System.Windows.Forms.ComboBox()
        Me.grbSearchSupp = New System.Windows.Forms.GroupBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtSearchText = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SupplierDetails = New eTender.SupplierDetails()
        Me.SupplierDetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SupplierDetailsTableAdapter = New eTender.SupplierDetailsTableAdapters.SupplierDetailsTableAdapter()
        Me.TableAdapterManager = New eTender.SupplierDetailsTableAdapters.TableAdapterManager()
        Me.grbDetail_SupplierDetails = New System.Windows.Forms.GroupBox()
        Me.txtDetail_TollFree = New System.Windows.Forms.TextBox()
        Me.TollFree = New System.Windows.Forms.Label()
        Me.txtDetail_Fax = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtDetail_Telephone = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtDetail_Email = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDetail_WebAddr = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDetail_IncTaxNo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDetail_VATNumber = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtDetail_RegNumber = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtDetail_SupplierName = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.grbDetail_PhysicalAddr = New System.Windows.Forms.GroupBox()
        Me.txtDetail_PhysicalCode = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.rtbDetail_Physical = New System.Windows.Forms.RichTextBox()
        Me.grbDetail_PostalAddr = New System.Windows.Forms.GroupBox()
        Me.txtDetail_PostalCode = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.rtbDetail_Postal = New System.Windows.Forms.RichTextBox()
        Me.grbDetail_Classification = New System.Windows.Forms.GroupBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.chkDetail_Sales = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Exporter = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Distributor = New System.Windows.Forms.CheckBox()
        Me.chkDetail_BlackOwned = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Repairs = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Manufacturer = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Services = New System.Windows.Forms.CheckBox()
        Me.chkDetail_Importer = New System.Windows.Forms.CheckBox()
        Me.chkDetail_ISO = New System.Windows.Forms.CheckBox()
        Me.grbDetail_PrefSite = New System.Windows.Forms.GroupBox()
        Me.cmbDetail_CollegeSite = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.grbDetail_MoreInfo = New System.Windows.Forms.GroupBox()
        Me.btnGrouping = New System.Windows.Forms.Button()
        Me.btnSales = New System.Windows.Forms.Button()
        Me.btnMain = New System.Windows.Forms.Button()
        Me.grbSearchSupp.SuspendLayout()
        CType(Me.SupplierDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SupplierDetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grbDetail_SupplierDetails.SuspendLayout()
        Me.grbDetail_PhysicalAddr.SuspendLayout()
        Me.grbDetail_PostalAddr.SuspendLayout()
        Me.grbDetail_Classification.SuspendLayout()
        Me.grbDetail_PrefSite.SuspendLayout()
        Me.grbDetail_MoreInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(7, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Search By:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cmbSearchBy
        '
        Me.cmbSearchBy.FormattingEnabled = True
        Me.cmbSearchBy.Items.AddRange(New Object() {"Registration Number", "Company Name"})
        Me.cmbSearchBy.Location = New System.Drawing.Point(81, 22)
        Me.cmbSearchBy.Name = "cmbSearchBy"
        Me.cmbSearchBy.Size = New System.Drawing.Size(254, 23)
        Me.cmbSearchBy.TabIndex = 1
        Me.cmbSearchBy.Text = "--- Search By ---"
        '
        'grbSearchSupp
        '
        Me.grbSearchSupp.Controls.Add(Me.btnClose)
        Me.grbSearchSupp.Controls.Add(Me.btnSearch)
        Me.grbSearchSupp.Controls.Add(Me.txtSearchText)
        Me.grbSearchSupp.Controls.Add(Me.Label2)
        Me.grbSearchSupp.Controls.Add(Me.Label1)
        Me.grbSearchSupp.Controls.Add(Me.cmbSearchBy)
        Me.grbSearchSupp.Location = New System.Drawing.Point(12, 12)
        Me.grbSearchSupp.Name = "grbSearchSupp"
        Me.grbSearchSupp.Size = New System.Drawing.Size(343, 122)
        Me.grbSearchSupp.TabIndex = 2
        Me.grbSearchSupp.TabStop = False
        Me.grbSearchSupp.Text = "Search for Supplier"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(173, 89)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(162, 23)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "Close Search Window"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(10, 89)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(157, 23)
        Me.btnSearch.TabIndex = 3
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtSearchText
        '
        Me.txtSearchText.Location = New System.Drawing.Point(82, 60)
        Me.txtSearchText.Name = "txtSearchText"
        Me.txtSearchText.Size = New System.Drawing.Size(253, 23)
        Me.txtSearchText.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(10, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 21)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Enter text:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'SupplierDetails
        '
        Me.SupplierDetails.DataSetName = "SupplierDetails"
        Me.SupplierDetails.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SupplierDetailsBindingSource
        '
        Me.SupplierDetailsBindingSource.DataMember = "SupplierDetails"
        Me.SupplierDetailsBindingSource.DataSource = Me.SupplierDetails
        '
        'SupplierDetailsTableAdapter
        '
        Me.SupplierDetailsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.SupplierDetailsTableAdapter = Me.SupplierDetailsTableAdapter
        Me.TableAdapterManager.UpdateOrder = eTender.SupplierDetailsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'grbDetail_SupplierDetails
        '
        Me.grbDetail_SupplierDetails.BackColor = System.Drawing.SystemColors.Info
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_TollFree)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.TollFree)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_Fax)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label8)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_Telephone)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label7)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_Email)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label6)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_WebAddr)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label5)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_IncTaxNo)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label4)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_VATNumber)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label3)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_RegNumber)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label9)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.txtDetail_SupplierName)
        Me.grbDetail_SupplierDetails.Controls.Add(Me.Label10)
        Me.grbDetail_SupplierDetails.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbDetail_SupplierDetails.Location = New System.Drawing.Point(12, 140)
        Me.grbDetail_SupplierDetails.Name = "grbDetail_SupplierDetails"
        Me.grbDetail_SupplierDetails.Size = New System.Drawing.Size(506, 309)
        Me.grbDetail_SupplierDetails.TabIndex = 3
        Me.grbDetail_SupplierDetails.TabStop = False
        Me.grbDetail_SupplierDetails.Text = "Supplier Details"
        '
        'txtDetail_TollFree
        '
        Me.txtDetail_TollFree.Location = New System.Drawing.Point(195, 275)
        Me.txtDetail_TollFree.Name = "txtDetail_TollFree"
        Me.txtDetail_TollFree.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_TollFree.TabIndex = 9
        '
        'TollFree
        '
        Me.TollFree.Location = New System.Drawing.Point(10, 270)
        Me.TollFree.Name = "TollFree"
        Me.TollFree.Size = New System.Drawing.Size(176, 22)
        Me.TollFree.TabIndex = 16
        Me.TollFree.Text = "Toll Free:"
        Me.TollFree.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_Fax
        '
        Me.txtDetail_Fax.Location = New System.Drawing.Point(195, 245)
        Me.txtDetail_Fax.Name = "txtDetail_Fax"
        Me.txtDetail_Fax.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_Fax.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(10, 242)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(176, 26)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Fax No.:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_Telephone
        '
        Me.txtDetail_Telephone.Location = New System.Drawing.Point(195, 215)
        Me.txtDetail_Telephone.Name = "txtDetail_Telephone"
        Me.txtDetail_Telephone.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_Telephone.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(7, 215)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 23)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Telephone No.:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_Email
        '
        Me.txtDetail_Email.Location = New System.Drawing.Point(195, 182)
        Me.txtDetail_Email.Name = "txtDetail_Email"
        Me.txtDetail_Email.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_Email.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(10, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(176, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Email:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_WebAddr
        '
        Me.txtDetail_WebAddr.Location = New System.Drawing.Point(195, 152)
        Me.txtDetail_WebAddr.Name = "txtDetail_WebAddr"
        Me.txtDetail_WebAddr.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_WebAddr.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(10, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(176, 18)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Web Address:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_IncTaxNo
        '
        Me.txtDetail_IncTaxNo.Location = New System.Drawing.Point(195, 122)
        Me.txtDetail_IncTaxNo.Name = "txtDetail_IncTaxNo"
        Me.txtDetail_IncTaxNo.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_IncTaxNo.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(10, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(176, 26)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Income Tax Ref. No.:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_VATNumber
        '
        Me.txtDetail_VATNumber.Location = New System.Drawing.Point(195, 92)
        Me.txtDetail_VATNumber.Name = "txtDetail_VATNumber"
        Me.txtDetail_VATNumber.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_VATNumber.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(7, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(179, 28)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "VAT Registration No.:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_RegNumber
        '
        Me.txtDetail_RegNumber.Location = New System.Drawing.Point(195, 64)
        Me.txtDetail_RegNumber.Name = "txtDetail_RegNumber"
        Me.txtDetail_RegNumber.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_RegNumber.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(7, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 23)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Company/CC Registration No.:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtDetail_SupplierName
        '
        Me.txtDetail_SupplierName.Location = New System.Drawing.Point(195, 34)
        Me.txtDetail_SupplierName.Name = "txtDetail_SupplierName"
        Me.txtDetail_SupplierName.Size = New System.Drawing.Size(294, 23)
        Me.txtDetail_SupplierName.TabIndex = 1
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(7, 34)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(179, 23)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Supplier Name:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'grbDetail_PhysicalAddr
        '
        Me.grbDetail_PhysicalAddr.BackColor = System.Drawing.SystemColors.Info
        Me.grbDetail_PhysicalAddr.Controls.Add(Me.txtDetail_PhysicalCode)
        Me.grbDetail_PhysicalAddr.Controls.Add(Me.Label11)
        Me.grbDetail_PhysicalAddr.Controls.Add(Me.rtbDetail_Physical)
        Me.grbDetail_PhysicalAddr.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbDetail_PhysicalAddr.Location = New System.Drawing.Point(263, 455)
        Me.grbDetail_PhysicalAddr.Name = "grbDetail_PhysicalAddr"
        Me.grbDetail_PhysicalAddr.Size = New System.Drawing.Size(255, 149)
        Me.grbDetail_PhysicalAddr.TabIndex = 5
        Me.grbDetail_PhysicalAddr.TabStop = False
        Me.grbDetail_PhysicalAddr.Text = "Physical Address"
        '
        'txtDetail_PhysicalCode
        '
        Me.txtDetail_PhysicalCode.Location = New System.Drawing.Point(61, 120)
        Me.txtDetail_PhysicalCode.Name = "txtDetail_PhysicalCode"
        Me.txtDetail_PhysicalCode.Size = New System.Drawing.Size(61, 23)
        Me.txtDetail_PhysicalCode.TabIndex = 13
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(11, 121)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 23)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Code:"
        '
        'rtbDetail_Physical
        '
        Me.rtbDetail_Physical.Location = New System.Drawing.Point(7, 20)
        Me.rtbDetail_Physical.Name = "rtbDetail_Physical"
        Me.rtbDetail_Physical.Size = New System.Drawing.Size(242, 94)
        Me.rtbDetail_Physical.TabIndex = 12
        Me.rtbDetail_Physical.Text = ""
        '
        'grbDetail_PostalAddr
        '
        Me.grbDetail_PostalAddr.BackColor = System.Drawing.SystemColors.Info
        Me.grbDetail_PostalAddr.Controls.Add(Me.txtDetail_PostalCode)
        Me.grbDetail_PostalAddr.Controls.Add(Me.Label12)
        Me.grbDetail_PostalAddr.Controls.Add(Me.rtbDetail_Postal)
        Me.grbDetail_PostalAddr.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbDetail_PostalAddr.Location = New System.Drawing.Point(12, 455)
        Me.grbDetail_PostalAddr.Name = "grbDetail_PostalAddr"
        Me.grbDetail_PostalAddr.Size = New System.Drawing.Size(228, 149)
        Me.grbDetail_PostalAddr.TabIndex = 4
        Me.grbDetail_PostalAddr.TabStop = False
        Me.grbDetail_PostalAddr.Text = "Postal Address"
        '
        'txtDetail_PostalCode
        '
        Me.txtDetail_PostalCode.Location = New System.Drawing.Point(55, 120)
        Me.txtDetail_PostalCode.Name = "txtDetail_PostalCode"
        Me.txtDetail_PostalCode.Size = New System.Drawing.Size(61, 23)
        Me.txtDetail_PostalCode.TabIndex = 11
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(7, 121)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 23)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Code:"
        '
        'rtbDetail_Postal
        '
        Me.rtbDetail_Postal.Location = New System.Drawing.Point(7, 20)
        Me.rtbDetail_Postal.Name = "rtbDetail_Postal"
        Me.rtbDetail_Postal.Size = New System.Drawing.Size(215, 94)
        Me.rtbDetail_Postal.TabIndex = 10
        Me.rtbDetail_Postal.Text = ""
        '
        'grbDetail_Classification
        '
        Me.grbDetail_Classification.BackColor = System.Drawing.SystemColors.Info
        Me.grbDetail_Classification.Controls.Add(Me.Label13)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Sales)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Exporter)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Distributor)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_BlackOwned)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Repairs)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Manufacturer)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Services)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_Importer)
        Me.grbDetail_Classification.Controls.Add(Me.chkDetail_ISO)
        Me.grbDetail_Classification.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbDetail_Classification.Location = New System.Drawing.Point(524, 213)
        Me.grbDetail_Classification.Name = "grbDetail_Classification"
        Me.grbDetail_Classification.Size = New System.Drawing.Size(298, 268)
        Me.grbDetail_Classification.TabIndex = 21
        Me.grbDetail_Classification.TabStop = False
        Me.grbDetail_Classification.Text = "Company / Supplier Classification"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(12, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(204, 13)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Please select ALL relevant options"
        '
        'chkDetail_Sales
        '
        Me.chkDetail_Sales.AutoSize = True
        Me.chkDetail_Sales.Location = New System.Drawing.Point(12, 241)
        Me.chkDetail_Sales.Name = "chkDetail_Sales"
        Me.chkDetail_Sales.Size = New System.Drawing.Size(55, 19)
        Me.chkDetail_Sales.TabIndex = 23
        Me.chkDetail_Sales.Text = "Sales"
        Me.chkDetail_Sales.UseVisualStyleBackColor = True
        '
        'chkDetail_Exporter
        '
        Me.chkDetail_Exporter.AutoSize = True
        Me.chkDetail_Exporter.Location = New System.Drawing.Point(12, 220)
        Me.chkDetail_Exporter.Name = "chkDetail_Exporter"
        Me.chkDetail_Exporter.Size = New System.Drawing.Size(72, 19)
        Me.chkDetail_Exporter.TabIndex = 22
        Me.chkDetail_Exporter.Text = "Exporter"
        Me.chkDetail_Exporter.UseVisualStyleBackColor = True
        '
        'chkDetail_Distributor
        '
        Me.chkDetail_Distributor.AutoSize = True
        Me.chkDetail_Distributor.Location = New System.Drawing.Point(12, 196)
        Me.chkDetail_Distributor.Name = "chkDetail_Distributor"
        Me.chkDetail_Distributor.Size = New System.Drawing.Size(87, 19)
        Me.chkDetail_Distributor.TabIndex = 21
        Me.chkDetail_Distributor.Text = "Distributor"
        Me.chkDetail_Distributor.UseVisualStyleBackColor = True
        '
        'chkDetail_BlackOwned
        '
        Me.chkDetail_BlackOwned.AutoSize = True
        Me.chkDetail_BlackOwned.Location = New System.Drawing.Point(12, 172)
        Me.chkDetail_BlackOwned.Name = "chkDetail_BlackOwned"
        Me.chkDetail_BlackOwned.Size = New System.Drawing.Size(97, 19)
        Me.chkDetail_BlackOwned.TabIndex = 20
        Me.chkDetail_BlackOwned.Text = "Black Owned"
        Me.chkDetail_BlackOwned.UseVisualStyleBackColor = True
        '
        'chkDetail_Repairs
        '
        Me.chkDetail_Repairs.AutoSize = True
        Me.chkDetail_Repairs.Location = New System.Drawing.Point(12, 148)
        Me.chkDetail_Repairs.Name = "chkDetail_Repairs"
        Me.chkDetail_Repairs.Size = New System.Drawing.Size(68, 19)
        Me.chkDetail_Repairs.TabIndex = 19
        Me.chkDetail_Repairs.Text = "Repairs"
        Me.chkDetail_Repairs.UseVisualStyleBackColor = True
        '
        'chkDetail_Manufacturer
        '
        Me.chkDetail_Manufacturer.AutoSize = True
        Me.chkDetail_Manufacturer.Location = New System.Drawing.Point(12, 124)
        Me.chkDetail_Manufacturer.Name = "chkDetail_Manufacturer"
        Me.chkDetail_Manufacturer.Size = New System.Drawing.Size(102, 19)
        Me.chkDetail_Manufacturer.TabIndex = 18
        Me.chkDetail_Manufacturer.Text = "Manufacturer"
        Me.chkDetail_Manufacturer.UseVisualStyleBackColor = True
        '
        'chkDetail_Services
        '
        Me.chkDetail_Services.AutoSize = True
        Me.chkDetail_Services.Location = New System.Drawing.Point(12, 100)
        Me.chkDetail_Services.Name = "chkDetail_Services"
        Me.chkDetail_Services.Size = New System.Drawing.Size(71, 19)
        Me.chkDetail_Services.TabIndex = 17
        Me.chkDetail_Services.Text = "Services"
        Me.chkDetail_Services.UseVisualStyleBackColor = True
        '
        'chkDetail_Importer
        '
        Me.chkDetail_Importer.AutoSize = True
        Me.chkDetail_Importer.Location = New System.Drawing.Point(12, 76)
        Me.chkDetail_Importer.Name = "chkDetail_Importer"
        Me.chkDetail_Importer.Size = New System.Drawing.Size(74, 19)
        Me.chkDetail_Importer.TabIndex = 16
        Me.chkDetail_Importer.Text = "Importer"
        Me.chkDetail_Importer.UseVisualStyleBackColor = True
        '
        'chkDetail_ISO
        '
        Me.chkDetail_ISO.AutoSize = True
        Me.chkDetail_ISO.Location = New System.Drawing.Point(12, 52)
        Me.chkDetail_ISO.Name = "chkDetail_ISO"
        Me.chkDetail_ISO.Size = New System.Drawing.Size(80, 19)
        Me.chkDetail_ISO.TabIndex = 15
        Me.chkDetail_ISO.Text = "ISO Listed"
        Me.chkDetail_ISO.UseVisualStyleBackColor = True
        '
        'grbDetail_PrefSite
        '
        Me.grbDetail_PrefSite.BackColor = System.Drawing.SystemColors.Info
        Me.grbDetail_PrefSite.Controls.Add(Me.cmbDetail_CollegeSite)
        Me.grbDetail_PrefSite.Controls.Add(Me.Label14)
        Me.grbDetail_PrefSite.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbDetail_PrefSite.Location = New System.Drawing.Point(524, 140)
        Me.grbDetail_PrefSite.Name = "grbDetail_PrefSite"
        Me.grbDetail_PrefSite.Size = New System.Drawing.Size(298, 66)
        Me.grbDetail_PrefSite.TabIndex = 20
        Me.grbDetail_PrefSite.TabStop = False
        Me.grbDetail_PrefSite.Text = "Preferred College Site"
        '
        'cmbDetail_CollegeSite
        '
        Me.cmbDetail_CollegeSite.FormattingEnabled = True
        Me.cmbDetail_CollegeSite.Location = New System.Drawing.Point(125, 34)
        Me.cmbDetail_CollegeSite.Name = "cmbDetail_CollegeSite"
        Me.cmbDetail_CollegeSite.Size = New System.Drawing.Size(166, 23)
        Me.cmbDetail_CollegeSite.TabIndex = 14
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(9, 34)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(110, 18)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "Preferred College Site"
        '
        'grbDetail_MoreInfo
        '
        Me.grbDetail_MoreInfo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.grbDetail_MoreInfo.Controls.Add(Me.btnGrouping)
        Me.grbDetail_MoreInfo.Controls.Add(Me.btnSales)
        Me.grbDetail_MoreInfo.Controls.Add(Me.btnMain)
        Me.grbDetail_MoreInfo.Location = New System.Drawing.Point(525, 488)
        Me.grbDetail_MoreInfo.Name = "grbDetail_MoreInfo"
        Me.grbDetail_MoreInfo.Size = New System.Drawing.Size(297, 116)
        Me.grbDetail_MoreInfo.TabIndex = 22
        Me.grbDetail_MoreInfo.TabStop = False
        Me.grbDetail_MoreInfo.Text = "More Info Options"
        '
        'btnGrouping
        '
        Me.btnGrouping.Location = New System.Drawing.Point(14, 78)
        Me.btnGrouping.Name = "btnGrouping"
        Me.btnGrouping.Size = New System.Drawing.Size(276, 23)
        Me.btnGrouping.TabIndex = 2
        Me.btnGrouping.Text = "Company Grouping Details"
        Me.btnGrouping.UseVisualStyleBackColor = True
        '
        'btnSales
        '
        Me.btnSales.Location = New System.Drawing.Point(14, 49)
        Me.btnSales.Name = "btnSales"
        Me.btnSales.Size = New System.Drawing.Size(276, 23)
        Me.btnSales.TabIndex = 1
        Me.btnSales.Text = "Main Sales Person Details"
        Me.btnSales.UseVisualStyleBackColor = True
        '
        'btnMain
        '
        Me.btnMain.Location = New System.Drawing.Point(14, 20)
        Me.btnMain.Name = "btnMain"
        Me.btnMain.Size = New System.Drawing.Size(276, 23)
        Me.btnMain.TabIndex = 0
        Me.btnMain.Text = "Main Contact Person Details"
        Me.btnMain.UseVisualStyleBackColor = True
        '
        'frmSupplierDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(827, 611)
        Me.Controls.Add(Me.grbDetail_MoreInfo)
        Me.Controls.Add(Me.grbDetail_Classification)
        Me.Controls.Add(Me.grbDetail_PrefSite)
        Me.Controls.Add(Me.grbDetail_PhysicalAddr)
        Me.Controls.Add(Me.grbDetail_PostalAddr)
        Me.Controls.Add(Me.grbDetail_SupplierDetails)
        Me.Controls.Add(Me.grbSearchSupp)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmSupplierDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Supplier Details"
        Me.grbSearchSupp.ResumeLayout(False)
        Me.grbSearchSupp.PerformLayout()
        CType(Me.SupplierDetails, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SupplierDetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grbDetail_SupplierDetails.ResumeLayout(False)
        Me.grbDetail_SupplierDetails.PerformLayout()
        Me.grbDetail_PhysicalAddr.ResumeLayout(False)
        Me.grbDetail_PhysicalAddr.PerformLayout()
        Me.grbDetail_PostalAddr.ResumeLayout(False)
        Me.grbDetail_PostalAddr.PerformLayout()
        Me.grbDetail_Classification.ResumeLayout(False)
        Me.grbDetail_Classification.PerformLayout()
        Me.grbDetail_PrefSite.ResumeLayout(False)
        Me.grbDetail_MoreInfo.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbSearchBy As System.Windows.Forms.ComboBox
    Friend WithEvents grbSearchSupp As System.Windows.Forms.GroupBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents txtSearchText As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SupplierDetails As eTender.SupplierDetails
    Friend WithEvents SupplierDetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SupplierDetailsTableAdapter As eTender.SupplierDetailsTableAdapters.SupplierDetailsTableAdapter
    Friend WithEvents TableAdapterManager As eTender.SupplierDetailsTableAdapters.TableAdapterManager
    Friend WithEvents grbDetail_SupplierDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtDetail_TollFree As System.Windows.Forms.TextBox
    Friend WithEvents TollFree As System.Windows.Forms.Label
    Friend WithEvents txtDetail_Fax As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_Telephone As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_Email As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_WebAddr As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_IncTaxNo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_VATNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_RegNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtDetail_SupplierName As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents grbDetail_PhysicalAddr As System.Windows.Forms.GroupBox
    Friend WithEvents txtDetail_PhysicalCode As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents rtbDetail_Physical As System.Windows.Forms.RichTextBox
    Friend WithEvents grbDetail_PostalAddr As System.Windows.Forms.GroupBox
    Friend WithEvents txtDetail_PostalCode As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents rtbDetail_Postal As System.Windows.Forms.RichTextBox
    Friend WithEvents grbDetail_Classification As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents chkDetail_Sales As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Exporter As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Distributor As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_BlackOwned As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Repairs As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Manufacturer As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Services As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_Importer As System.Windows.Forms.CheckBox
    Friend WithEvents chkDetail_ISO As System.Windows.Forms.CheckBox
    Friend WithEvents grbDetail_PrefSite As System.Windows.Forms.GroupBox
    Friend WithEvents cmbDetail_CollegeSite As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents grbDetail_MoreInfo As System.Windows.Forms.GroupBox
    Friend WithEvents btnMain As System.Windows.Forms.Button
    Friend WithEvents btnGrouping As System.Windows.Forms.Button
    Friend WithEvents btnSales As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
