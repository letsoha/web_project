﻿Public Class frmNewTender

    Dim SystemProcesses As New eTenderClass
    Dim strTenderNumber As String
    Public folder As New OpenFileDialog
    Public dsTenderDoc As New Object
    Dim Invitation As New frmInviteSupplier

    Private Sub btnNextTendInfo_Click(sender As Object, e As EventArgs) Handles btnNextTendInfo.Click
        Dim myConn As String
        Dim dsTender As String

        myConn = SystemProcesses.GetConnection()
        If myConn <> "true" Then
            MsgBox("No connection to System Database.", MsgBoxStyle.Critical)
        Else
            dsTender = SystemProcesses.AddTenderDetails(txtTenderNum.Text, txtNoticeInfo.Text, dtpIssueDate.Value, dtpClosingDate.Value, CDate(txtTime.Text), folder.FileName)

            If dsTender <> "true" Then
                MsgBox("Tender information was not added to Database.", MsgBoxStyle.Information)
            Else
                Me.Hide()
                If MsgBox("Would you like to invite suppliers for this tender?", MessageBoxButtons.YesNo) _
                            = DialogResult.Yes Then
                    Invitation = New frmInviteSupplier
                    Invitation.MdiParent = frmMainForm
                    Invitation.Show()
                Else
                    MsgBox("Tender details have been added successfully.", MsgBoxStyle.Information, MessageBoxButtons.OK)
                End If
            End If
        End If
    End Sub

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click

        Dim result = folder.ShowDialog()
        Dim myConn As String


        myConn = SystemProcesses.GetConnection()

        If myConn <> "true" Then
            MessageBox.Show("There was no connection to Database.", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            If result = 1 Then
                'System.IO.File.Copy(folder.FileName, SystemProcesses.AddTenderDocument(folder.OpenFile(), strTenderNumber))
                lblMessage.Visible = True
                lblMessage.Text = "File " & folder.FileName & " is ready to be saved. Click on Next to continue."
                btnNextTendInfo.Enabled = True
                btnUpload.Enabled = False
                dsTenderDoc = SystemProcesses.GetTenderDocument(txtTenderNum.Text)

            Else
                lblMessage.Visible = True
                lblMessage.Text = "File not uploaded."
            End If
        End If
    End Sub

    Private Sub frmNewTender_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnNextTendInfo.Enabled = False
    End Sub
End Class