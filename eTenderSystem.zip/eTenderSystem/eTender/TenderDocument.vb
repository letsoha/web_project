﻿Imports System.Data
Imports System.Data.OleDb

Public Class frmTenderDocument

    Dim SystemProcesses As New eTenderClass
    Public strTenderNumber As String
    Private Sub frmTenderDocument_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'WebBrowser.Navigate(System.IO.File.Open(frmNewTender.dsTenderDoc))
        btnFinish.Visible = False

    End Sub
End Class