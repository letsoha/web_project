﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInviteSupplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grbSelectSupp = New System.Windows.Forms.GroupBox()
        Me.cmbTenderNotice = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.cmbSupplierName = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstSuppliers = New System.Windows.Forms.ListBox()
        Me.btnAddToList = New System.Windows.Forms.Button()
        Me.btnSendInvite = New System.Windows.Forms.Button()
        Me.grbSelectSupp.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Calibri", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(463, 40)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Invite Supplier(s) to bid for a Tender"
        '
        'grbSelectSupp
        '
        Me.grbSelectSupp.Controls.Add(Me.cmbTenderNotice)
        Me.grbSelectSupp.Controls.Add(Me.Label3)
        Me.grbSelectSupp.Controls.Add(Me.btnRemove)
        Me.grbSelectSupp.Controls.Add(Me.cmbSupplierName)
        Me.grbSelectSupp.Controls.Add(Me.Label2)
        Me.grbSelectSupp.Controls.Add(Me.lstSuppliers)
        Me.grbSelectSupp.Controls.Add(Me.btnAddToList)
        Me.grbSelectSupp.Location = New System.Drawing.Point(13, 71)
        Me.grbSelectSupp.Name = "grbSelectSupp"
        Me.grbSelectSupp.Size = New System.Drawing.Size(548, 370)
        Me.grbSelectSupp.TabIndex = 1
        Me.grbSelectSupp.TabStop = False
        Me.grbSelectSupp.Text = "Select Supplier"
        '
        'cmbTenderNotice
        '
        Me.cmbTenderNotice.FormattingEnabled = True
        Me.cmbTenderNotice.Location = New System.Drawing.Point(314, 44)
        Me.cmbTenderNotice.Name = "cmbTenderNotice"
        Me.cmbTenderNotice.Size = New System.Drawing.Size(228, 23)
        Me.cmbTenderNotice.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(7, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(301, 23)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "For which Tender do you wish to invite suppliers ?:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(414, 174)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(128, 23)
        Me.btnRemove.TabIndex = 4
        Me.btnRemove.Text = "Remove Supplier"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'cmbSupplierName
        '
        Me.cmbSupplierName.FormattingEnabled = True
        Me.cmbSupplierName.Location = New System.Drawing.Point(314, 74)
        Me.cmbSupplierName.Name = "cmbSupplierName"
        Me.cmbSupplierName.Size = New System.Drawing.Size(228, 23)
        Me.cmbSupplierName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(33, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(275, 23)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Supplier:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lstSuppliers
        '
        Me.lstSuppliers.FormattingEnabled = True
        Me.lstSuppliers.ItemHeight = 15
        Me.lstSuppliers.Items.AddRange(New Object() {"Supplier Name" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Tender Notice", "---------------------------------------------------------------------------------" & _
                "---------------"})
        Me.lstSuppliers.Location = New System.Drawing.Point(10, 132)
        Me.lstSuppliers.Name = "lstSuppliers"
        Me.lstSuppliers.Size = New System.Drawing.Size(398, 229)
        Me.lstSuppliers.TabIndex = 3
        '
        'btnAddToList
        '
        Me.btnAddToList.Location = New System.Drawing.Point(314, 103)
        Me.btnAddToList.Name = "btnAddToList"
        Me.btnAddToList.Size = New System.Drawing.Size(192, 23)
        Me.btnAddToList.TabIndex = 2
        Me.btnAddToList.Text = "Add Supplier to List"
        Me.btnAddToList.UseVisualStyleBackColor = True
        '
        'btnSendInvite
        '
        Me.btnSendInvite.Location = New System.Drawing.Point(406, 467)
        Me.btnSendInvite.Name = "btnSendInvite"
        Me.btnSendInvite.Size = New System.Drawing.Size(155, 23)
        Me.btnSendInvite.TabIndex = 2
        Me.btnSendInvite.Text = "Send Invitation"
        Me.btnSendInvite.UseVisualStyleBackColor = True
        '
        'frmInviteSupplier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(568, 495)
        Me.Controls.Add(Me.btnSendInvite)
        Me.Controls.Add(Me.grbSelectSupp)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmInviteSupplier"
        Me.Text = "Invite Supplier"
        Me.grbSelectSupp.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grbSelectSupp As System.Windows.Forms.GroupBox
    Friend WithEvents btnAddToList As System.Windows.Forms.Button
    Friend WithEvents cmbSupplierName As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents lstSuppliers As System.Windows.Forms.ListBox
    Friend WithEvents cmbTenderNotice As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSendInvite As System.Windows.Forms.Button
End Class
